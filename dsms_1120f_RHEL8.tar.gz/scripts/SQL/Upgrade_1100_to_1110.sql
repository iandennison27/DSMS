alter table users add column `is_owner` int(1) NOT NULL DEFAULT '0' AFTER `active`;
alter table users add column `is_application_user` int(1) NOT NULL DEFAULT '0' AFTER `is_owner`;
alter table users add column `user_email` varchar(255) NULL AFTER `is_owner`;
alter table rules add column `rule_owner` int(11) NOT NULL DEFAULT '0' AFTER `active`;

CREATE TABLE `renewal_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL DEFAULT '0',
  `generation_date` date NOT NULL,
  `renew_expires` date NOT NULL,
  `status` int(1),
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
);

CREATE TABLE `renewal_tracking_rules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `renewal_id` int(11) NOT NULL DEFAULT '0',
  `rule_id` int(11) NOT NULL DEFAULT '0',
  `expires` date NOT NULL,
  `status` int(1),
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
);


#!/bin/bash

# Script to rollout local sudoers, only if changed.
export PARM=$*
export HCNT=`echo "${PARM}" |grep -i help |wc -l`
if (( $HCNT > 0 ))
then
        echo "dsms_local_dist.sh        - help - this message"
        echo "                          - force - rollout regardless"
        exit
fi

export FCNT=`echo "${PARM}" |grep -i force |wc -l`

# Check if changed
diff /home/transport/upload/sudoers /etc/sudoers 2>&1 > /dev/null
export DIFFCNT=$?

if [[ ${DIFFCNT} != "0" || ${FCNT} != "0" ]]
then
        # Check
        /sbin/visudo -c -f /home/transport/upload/sudoers 2>&1
        export VICNT=$?
        if [[ "${VICNT}" == "0" ]]
        then
                cp /home/transport/upload/sudoers /etc/sudoers
        fi
fi


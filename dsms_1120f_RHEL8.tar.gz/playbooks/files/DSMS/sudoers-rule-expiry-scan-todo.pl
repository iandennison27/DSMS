#!/usr/bin/perl

# Name: sudoers-rule-expiry-scan-todo.pl
# Author: Ian Dennison
# Purpose: Report on Rules that have non-application users, and are npot assigned to an owner.
#
# Version
# | 1.0 | 20 Nov 2024 | Initial Release |
#

# Scan for affected rules
use strict;
use POSIX qw(strftime);
use DateTime;
use MIME::Lite;
use Date::Parse qw(str2time);

require 'common.pl';
my $DB_Management = DB_Management();
my $DB_Sudoers = DB_Sudoers();
my $Sudoers_Location = "";
my $Default_Environment = Default_Environment();
my $System_Name = System_Name();
my $Debug_Build = Debug_Build();
my $Version = Version();
my $md5sum = md5sum();
my $cut = cut();
my $visudo = visudo();
my $cp = cp();
my $ls = ls();
my $grep = sudo_grep();
my $head = head();
my $Owner = Owner_ID();
my $Group = Group_ID();
my $Date = strftime "%Y-%m-%d", localtime;

my $Expiry_Period= Expiry_Period();
my $Expiry_Warning= Expiry_Warning();
my $Expiry_Cleanup= Expiry_Cleanup();
my $Owner_Notification_Email= Owner_Notification_Email();

my $Message_Output_Limit=3;
my $CR="\n";

# Generate template for email
# my $html_intro='From: root@' . $Hostname . $CR . 'To: ' . $Owner_Notification_Email . $CR . 'MIME-Version: 1.0' . $CR . 'Subject: Sudoers Rules with Clashes on Application and Non-Application Userids' . $CR . 'Content-Type: text/html' . $CR . '<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN>' . $CR . 'The following rules have been found to use both Application and Non-Application Userids. You should split these out at your earliest convenience<br />';
my $html_intro='<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN>' . $CR . 'The following rules have been found to use both Application and Non-Application Userids. You should split these out at your earliest convenience<br />';

my $html_header='<table border="1" cellspacing="0" cellpadding="1">
                <tr><td style="width:10px"></td><td style="width:10px"></td><td style="width:10px"></td><td width=2px>Rule No</td><td width=2px>Rule Name</td><td>Application Userids in Groups</td><td>Application Userids in Rules</td><td>Non-Application Userids in Groups</td><td>Non-Application Userids in Rules</td></tr>';
my $html_code="";
my $html_footer="</table><br />" . $CR . "Please review and action" . $CR . "</body>";

# Connect to Database, get list of rules with owners that expire within 14 days (change to common.pl value later)
# my $Select_Owners = $DB_Sudoers->prepare("SELECT DISTINCT `rule_owner` FROM `rules` where `expires` < NOW()-14");
# EXAMPLE: SELECT * FROM `rules` WHERE `rule_owner` <> '0' AND `expires` <> '0000-00-00' AND `expires` < NOW() + INTERVAL 14 DAY AND `expires` >= NOW();
#
# OLD CODE, SCAN FOR ALL RULES AFFECTED INSTEAD
# my $Select_Affected_Rules_Query = $DB_Sudoers->prepare("SELECT `id`, `name` FROM `rules`
#	WHERE `rule_owner` <> '0'
#	AND `expires` <> '0000-00-00'");
my $Select_Affected_Rules_Query = $DB_Sudoers->prepare("SELECT `id`, `name`,`expires`,`rule_owner` FROM `rules`");
$Select_Affected_Rules_Query->execute();
while (my @Select_Affected_Rules = $Select_Affected_Rules_Query->fetchrow_array() )
{
	# Get Rule details
        my $Rule_ID = $Select_Affected_Rules[0];
        my $Rule_Name = $Select_Affected_Rules[1];
        my $Rule_Expires = $Select_Affected_Rules[2];
        my $Rule_Owner = $Select_Affected_Rules[3];

#	print "Rule id: $Rule_ID, Rule Name: $Rule_Name, Rule Expires: $Rule_Expires, Rule Owner: $Rule_Owner\n";

	if ( $Rule_Expires eq '0000-00-00' )
	{
#		print "Expires empty\n";
	}

	# Loop through and get links to users direct from rules
	my $Affected_Users_Query_Non_Owner="";
	my $Affected_User_Groups_Query_Non_Owner="";
	my $Affected_Users_Query_Owner="";
	my $Affected_User_Groups_Query_Owner="";

	# Users linked to rule that are not owners
	my $Select_Affected_Users_Query = $DB_Sudoers->prepare("SELECT rules.id, users.username, users.is_application_user FROM rules
		inner join lnk_rules_to_users ON rules.id = lnk_rules_to_users.rule
		inner join users on lnk_rules_to_users.user = users.id
		WHERE  rules.id = ?
		AND users.is_application_user = 0");	
	$Select_Affected_Users_Query->execute($Rule_ID);
	my $Affected_Users_Non_Owner_Count =  $Select_Affected_Users_Query->rows();
        while (my @Select_User_Query_Non_Owner = $Select_Affected_Users_Query->fetchrow_array() )
        {
                        # Grab data
                        my $User_Non_Owner_Rule_Id=$Select_User_Query_Non_Owner[0];
                        my $User_Non_Owner_User_Name=$Select_User_Query_Non_Owner[1];
			$Affected_Users_Query_Non_Owner = $Affected_Users_Query_Non_Owner .  $User_Non_Owner_User_Name . ", ";
	}
	$Affected_Users_Query_Non_Owner =~ s/, $//g;
			
	# Users linked to rule that are owners
	my $Select_Affected_Users_Query_Owner = $DB_Sudoers->prepare("SELECT rules.id, users.username, users.is_application_user FROM rules
		inner join lnk_rules_to_users ON rules.id = lnk_rules_to_users.rule
		inner join users on lnk_rules_to_users.user = users.id
		WHERE  rules.id = ?
		AND users.is_application_user = 1");	
	$Select_Affected_Users_Query_Owner->execute($Rule_ID);
	my $Affected_Users_Owner_Count =  $Select_Affected_Users_Query_Owner->rows();
        while (my @Select_User_Query_Owner = $Select_Affected_Users_Query_Owner->fetchrow_array() )
        {
                        # Grab data
                        my $User_Owner_Rule_Id=$Select_User_Query_Owner[0];
                        my $User_Owner_User_Name=$Select_User_Query_Owner[1];
			$Affected_Users_Query_Owner = $Affected_Users_Query_Owner .  $User_Owner_User_Name . ", ";
	}
	$Affected_Users_Query_Owner =~ s/, $//g;
	
	# Now loop through and find users inside user groups that are affected
	my $Select_Affected_User_Groups_Query = $DB_Sudoers->prepare("SELECT  rules.id, users.username, users.is_application_user from rules
		inner join lnk_rules_to_user_groups ON rules.id = lnk_rules_to_user_groups.rule
		inner join lnk_user_groups_to_users on lnk_rules_to_user_groups.user_group= lnk_user_groups_to_users.group
		inner join users on lnk_user_groups_to_users.user= users.id
		WHERE rules.id = ?
		AND users.is_application_user = 0");	
	$Select_Affected_User_Groups_Query->execute($Rule_ID);
	my $Affected_User_Groups_Non_Owner_Count =  $Select_Affected_User_Groups_Query->rows();
        while (my @Select_User_Group_Query_Non_Owner = $Select_Affected_User_Groups_Query->fetchrow_array() )
        {
                        # Grab data
                        my $User_Group_Non_Owner_Rule_Id=$Select_User_Group_Query_Non_Owner[0];
                        my $User_Group_Non_Owner_User_Name=$Select_User_Group_Query_Non_Owner[1];
			$Affected_User_Groups_Query_Non_Owner = $Affected_User_Groups_Query_Non_Owner .  $User_Group_Non_Owner_User_Name . ", ";
	}
	$Affected_User_Groups_Query_Non_Owner =~ s/, $//g;
	
	my $Select_Affected_User_Groups_Query_Owner = $DB_Sudoers->prepare("SELECT  rules.id, users.username, users.is_application_user from rules
		inner join lnk_rules_to_user_groups ON rules.id = lnk_rules_to_user_groups.rule
		inner join lnk_user_groups_to_users on lnk_rules_to_user_groups.user_group= lnk_user_groups_to_users.group
		inner join users on lnk_user_groups_to_users.user= users.id
		WHERE rules.id = ?
		AND users.is_application_user = 1");	
	$Select_Affected_User_Groups_Query_Owner->execute($Rule_ID);
	my $Affected_User_Groups_Non_Owner_Count =  $Select_Affected_User_Groups_Query_Owner->rows();
        while (my @Select_User_Group_Query_Owner = $Select_Affected_User_Groups_Query_Owner->fetchrow_array() )
        {
                        # Grab data
                        my $User_Group_Owner_Rule_Id=$Select_User_Group_Query_Owner[0];
                        my $User_Group_Owner_User_Name=$Select_User_Group_Query_Owner[1];
			$Affected_User_Groups_Query_Owner = $Affected_User_Groups_Query_Owner .  $User_Group_Owner_User_Name . ", ";
	}
	$Affected_User_Groups_Query_Owner =~ s/, $//g;

	# Output results
	# print "users rules nonowners $Affected_Users_Non_Owner_Count; list - $Affected_Users_Query_Non_Owner\n";	
	# print "users rules owners $Affected_Users_Owner_Count; list - $Affected_Users_Query_Owner\n";	
	# print "user_groups rules nonowners $Affected_User_Groups_Non_Owner_Count; list - $Affected_User_Groups_Query_Non_Owner\n";	
	# print "user_groups rules owners $Affected_User_Groups_Non_Owner_Count; list - $Affected_User_Groups_Query_Owner\n";	

	my $Total_Non_Owner_Count=$Affected_Users_Non_Owner_Count+$Affected_User_Groups_Non_Owner_Count;
	my $Total_Owner_Count=$Affected_Users_Owner_Count+$Affected_User_Groups_Non_Owner_Count;

#	print "Rule $Rule_ID, Total_Non_Owner_Count = $Total_Non_Owner_Count\n";
	if ( $Total_Non_Owner_Count > 0 )
	{
		# Check expiry
#		print "Rule $Rule_ID, Rule_Expires  $Rule_Expires Ruile_Owner $Rule_Owner\n";
        	if ( ( $Rule_Expires eq '0000-00-00' ) || ( $Rule_Owner eq 0 ) )
        	{
			# Check date
			my $Print_Flag=1;
			if ( $Rule_Expires ne '0000-00-00' )
			{
				my $Work_Expires=str2time($Rule_Expires);	
				my $currenttime=time();
				my $diff=$Work_Expires-$currenttime;
				if ( $diff < 1 )
				{
					$Print_Flag=0;
				}
			}
			if (  $Print_Flag eq 1 )
			{
				print "Rule id: $Rule_ID, Rule Name: $Rule_Name, Rule Expires: $Rule_Expires, Rule Owner: $Rule_Owner Print_Flag $Print_Flag\n";
			}
		}
		# Output to email message
		# print "CLASH! Mixup on application owner and non-application_owner in rules\n";
		# $html_code = $html_code .' <tr><td style="width:10px"></td><td style="width:10px"></td><td style="width:10px"></td><td width=2px>' . $Rule_ID . '</td><td width=2px>' . $Rule_Name . '</td><td>' . $Affected_User_Groups_Query_Owner . '</td><td>' . $Affected_Users_Query_Owner . '</td><td>' . $Affected_User_Groups_Query_Non_Owner . '</td><td>' . $Affected_Users_Query_Non_Owner . '</td></tr>';
	}
}

exit;


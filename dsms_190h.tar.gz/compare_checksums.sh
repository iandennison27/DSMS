#!/bin/bash

# Script compare checksums
export SRCDIR=/var/www/html
export DESTDIR=/home/fred/playbooks/files/DSMS/

cd ${SRCDIR}; sum * > /tmp/src1
cd ${DESTDIR}; sum * > /tmp/dest1

cat /tmp/src1 > /tmp/work1
cat /tmp/dest1 >> /tmp/work1

printf "   Src    Dest  Fname"
for i in $(cat /tmp/work1 |awk '{print $3}' |sort -u)
do
	export SRC=`grep " ${i}$" /tmp/src1 |awk '{print $1"_"$2}'`
	export DEST=`grep " ${i}$" /tmp/dest1 |awk '{print $1"_"$2}'`

	if [[ "${SRC}" != "${DEST}" ]]
	then
		export FLAG="XXXXX"
	else
		export FLAG=""
	fi
		
	printf "  %-12s | %-12s | %s %s\n" "${SRC}" "${DEST}" ${i} "${FLAG}"
done

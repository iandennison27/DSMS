Use 'Sudoers';
FLUSH PRIVILEGES;
drop user 'Management'@'localhost';
drop user 'Sudoers'@'localhost';

#!/bin/bash

# script to expand out sudoers
export SRCFILE=test2

function enter_filenames
{
	# Enter original and new file
	export ORIGFILE=`grep "^ORIGFILE:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	printf "  Original File: %s\n" "${ORIGFILE}"
	printf "    Enter File name:"
	read NEWORIG
	if [[ "${NEWORIG}" != "" ]]
	then
		if [[ ! -f ${NEWORIG} ]]
		then
			echo "Not a valid filename - return to continue"
			read
		else
			grep -v "ORIGFILE:" ${CFGFILE} > ${CFGFILE}_2
			echo "ORIGFILE:${NEWORIG}" >> ${CFGFILE}_2
			cp ${CFGFILE}_2 ${CFGFILE}
		fi
	fi
	export NEWFILE=`grep "^NEWGFILE:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	printf "  New File: %s\n" "${NEWFILE}"
	printf "    Enter File name:"
	read NEWNEW
	if [[ "${NEWNEW}" != "" ]]
	then
		if [[ ! -f ${NEWNEW} ]]
		then
			echo "Not a valid filename - return to continue"
			read
		else
			grep -v "NEWFILE:" ${CFGFILE} > ${CFGFILE}_2
			echo "NEWFILE:${NEWNEW}" >> ${CFGFILE}_2
			cp ${CFGFILE}_2 ${CFGFILE}
		fi
	fi

}

function analysis_defaults
{
	# Analyse the defaults - generate extracts
	cat /dev/null > /tmp/work_defaults_warn_${PID}
	echo " Analysing defaults - source ${ORIGFILE}"
	cat ${ORIGFILE} | sed "s/=/ = /g" |sed "s/+ =/ += /g" |awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g' |grep "^Defaults" > /tmp/work_defaults_source_${PID}
	cat /tmp/work_defaults_source_${PID}
	echo " Analysing defaults - dest ${NEWFILE}"
	cat ${NEWFILE} | sed "s/=/ = /g" |sed "s/+ =/ += /g" | awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g'  |grep "^Defaults" > /tmp/work_defaults_dest_${PID}
	cat  /tmp/work_defaults_dest_${PID}
	
	# Strip out secure path AAAA
	echo "Examine defaults"
	grep "Defaults" /tmp/work_defaults_source_${PID} |awk '$2 == "secure_path" {print $0}' |awk -F"=" '{for(i=2;i<=NF;i++) {printf("%s=", $i)}}{printf "\n"}' |sed 's/=$//g' |sed 's/"//g' |sed 's/:/ /g' |awk '{for(i=1;i<=NF;i++) {printf("ORIG:%s\n", $i)}}' > /tmp/work_defaults_source_secure_${PID}
	export ORIGCNT=`cat /tmp/work_defaults_source_secure_${PID} |wc -l`
	if (( $ORIGCNT < 1 ))
	then
		echo "ORIG:" >> /tmp/work_defaults_dest_secure_${PID}
	fi
		
	grep "Defaults" /tmp/work_defaults_dest_${PID} |awk '$2 == "secure_path" {print $0}' |awk -F"=" '{for(i=2;i<=NF;i++) {printf("%s=", $i)}}{printf "\n"}' |sed 's/=$//g' |sed 's/"//g' |sed 's/:/ /g' | awk '{for(i=1;i<=NF;i++) {printf("NEW:%s\n", $i)}}'  > /tmp/work_defaults_dest_secure_${PID}
	export NEWCNT=`cat /tmp/work_defaults_dest_secure_${PID} |wc -l`
	if (( $NEWCNT < 1 ))
	then
		echo "NEW:" >> /tmp/work_defaults_dest_secure_${PID}
	fi
	# Loop around showing securepath results
	cat  /tmp/work_defaults_source_secure_${PID} >  /tmp/work_defaults_source_both_${PID}
	cat /tmp/work_defaults_dest_secure_${PID} >> /tmp/work_defaults_source_both_${PID}

	printf " Secure_Path  |"	
	for i in $(cat  /tmp/work_defaults_source_both_${PID} |awk -F":" '{print $1}' |sort -ur)
	do
		printf " %-12s |" ${i}
	done
	printf "\n==============+==============+==============+\n"

	for i in $(cat /tmp/work_defaults_source_both_${PID} |awk -F":" '{print $2}' |awk 'NF > 0 {print $1}' |sort -u)	
	do
		printf " %-12s |" ${i}
	
		for j in $(cat /tmp/work_defaults_source_both_${PID} |awk -F":" '{print $1}' |sort -ur)
		do
			export FNDCNT=`grep "^${j}:${i}$" /tmp/work_defaults_source_both_${PID} |wc -l`
			if (( $FNDCNT < 1 ))
			then
				printf "      -       |"
			else
				printf "      X       |"
			fi
		done
		printf "\n"

	done

	# Strip out environment variables, strip out after env_reset (sequence is important)
	echo
	echo "Examine environment"
	grep "Defaults" /tmp/work_defaults_source_${PID} |awk '$2 == "env_keep" || $2 == "env_reset" {print $0}' |sed 's/env_keep=/env_keep = /g' |sed 's/env_keep+=/env_keep += /g' |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_defaults_source_env_${PID}
	export LASTORIGRESET=`grep "env_keep" /tmp/work_defaults_source_env_${PID} |awk '$3 == "=" {print $0}' |tail -n 1 |awk -F":" '{print $1}'`
	export REGLIST=`cat /tmp/work_defaults_source_env_${PID} |awk -F":" -vstartseq=${LASTORIGRESET} '$1 >= startseq {printf("%s ", $1)}'`

	cat /dev/null > /tmp/work_defaults_combined_env_trim_${PID}	
	for i in $(echo "${REGLIST}")
	do
		grep "^${i}:" /tmp/work_defaults_source_env_${PID} |sed "s/^${i}://g" | awk -F"=" '{for(i=2;i<=NF;i++) {printf("%s=", $i)}}{printf "\n"}' |sed 's/=$//g' |sed 's/"//g' |awk '{for(i=1;i<=NF;i++) {printf("ORIG:%s\n", $i)}}'>> /tmp/work_defaults_combined_env_trim_${PID}
	done
	
	grep "Defaults" /tmp/work_defaults_dest_${PID} |awk '$2 == "env_keep" || $2 == "env_reset" {print $0}' |sed 's/env_keep=/env_keep = /g' |sed 's/env_keep+=/env_keep += /g' |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_defaults_dest_env_${PID}
	export LASTNEWESET=`grep "env_keep" /tmp/work_defaults_dest_env_${PID} |awk '$3 == "=" {print $0}' |tail -n 1 |awk -F":" '{print $1}'`
	export REGLIST=`cat /tmp/work_defaults_dest_env_${PID} |awk -F":" -vstartseq=${LASTONEWRESET} '$1 >= startseq {printf("%s ", $1)}'`

	for i in $(echo "${REGLIST}")
	do
		grep "^${i}:" /tmp/work_defaults_dest_env_${PID} |sed "s/^${i}://g" | awk -F"=" '{for(i=2;i<=NF;i++) {printf("%s=", $i)}}{printf "\n"}' |sed 's/=$//g' |sed 's/"//g' |awk '{for(i=1;i<=NF;i++) {printf("NEW:%s\n", $i)}}'>> /tmp/work_defaults_combined_env_trim_${PID}
	done

	# List out environment defaults
	printf "\n"
	printf " Environment          |"	
	for i in $(cat  /tmp/work_defaults_combined_env_trim_${PID} |awk -F":" '{print $1}' |sort -ur)
	do
		printf " %-12s |" ${i}
	done
	printf "\n======================+==============+==============+\n"

	# Loop through components"
	for i in $(cat /tmp/work_defaults_combined_env_trim_${PID} |awk -F":" '{print $2}' |sort -u)
	do
		# output environment variable
		printf " %-20s |" ${i}
		for j in $(cat  /tmp/work_defaults_combined_env_trim_${PID} |awk -F":" '{print $1}' |sort -ur)
		do
			export FNDCNT=`grep "^${j}:${i}$" /tmp/work_defaults_combined_env_trim_${PID} |wc -l`
			if (( $FNDCNT > 0 ))
			then
				printf "       X      |"
			else
				printf "       -      |"
			fi
		done
		printf "\n"
	done

	# Strip out all others defaults
	cat /tmp/work_defaults_source_${PID} |awk '$2 != "env_reset" && $2 != "env_keep" && $2 != "secure_path" {print $0}' > /tmp/work_defaults_source_other_${PID}
	cat /tmp/work_defaults_dest_${PID} |awk '$2 != "env_reset" && $2 != "env_keep" && $2 != "secure_path" {print $0}' > /tmp/work_defaults_dest_other_${PID}
	ls -al /tmp/work_defaults_source_other_${PID} /tmp/work_defaults_dest_other_${PID}
	echo "Return to continue"
	read
}

function analysis_extracts
{
	# Find matching lines
	cat /tmp/work_expand_source_${PID} |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_expand_source_work_${PID}
	cp /tmp/work_expand_dest_${PID} /tmp/work_expand_dest_work_${PID}

	cat /dev/null > /tmp/work_expand_results_${PID}
	export TOTCNT=`cat  /tmp/work_expand_source_work_${PID} |wc -l`
	export MATCHCNT=0
	export NONCONDCNT=0
	export DIFFCONDCNT=0
	export MISSUSERCNT=0
	export UNALLOCLIST=""
	for i in $(cat /tmp/work_expand_source_work_${PID} |awk -F":" '{print $1}')
	do
		# Strip out search param
		export SRHPARM=`grep "^${i}:" /tmp/work_expand_source_work_${PID} |head -n 1 |sed "s/^${i}://g"`
		export FNDCNT=`grep "^${SRHPARM}$" /tmp/work_expand_dest_${PID} |wc -l`
		if (( $FNDCNT > 0 ))
		then
			# Update counts and flags, strip out from dest
			export MATCHCNT=`expr ${MATCHCNT} \+ ${FNDCNT}`	
			echo "MATCH:SRC:${i}:${SRHPARM}" >> /tmp/work_expand_results_${PID}
			grep "^${SRHPARM}$" /tmp/work_expand_dest_${PID} |awk -vitem=${i} '{print "MATCH:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
			grep -v "^${SRHPARM}$" /tmp/work_expand_dest_work_${PID} > /tmp/work_expand_dest_work_${PID}_2
			cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
			continue
		fi
		export NONCONDPARM=`echo "${SRHPARM}" |awk -F":" '{print $1":"$2":"$3"::"$5}'`
		export FNDCNT=`grep "^${NONCONDPARM}$" /tmp/work_expand_dest_${PID} |wc -l`
		if (( $FNDCNT > 0 ))
		then
			export NONCONDCNT=`expr ${NONCONDCNT} \+ ${FNDCNT}`
			echo "NONCOND:SRC:${i}:${SRHPARM}" >> /tmp/work_expand_results_${PID}
			grep "^${NONCONDPARM}$" /tmp/work_expand_dest_${PID} |awk -vitem=${i} '{print "NONCOND:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
			grep -v "^${NONCONDPARM}$" /tmp/work_expand_dest_work_${PID} > /tmp/work_expand_dest_work_${PID}_2
			cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
			continue
		fi

		# Check for different CONDITION
		export DIFFCONDPARM=`echo "${SRHPARM}" |awk -F":" '{print $1":"$2":"$3}'`
		export DIFFCONDSUFFIX=`echo "${SRHPARM}" |awk -F":" '{print $5}'`
		export FNDCNT=`grep "^${DIFFCONDPARM}:" /tmp/work_expand_dest_${PID} |grep ":${DIFFCONDSUFFIX}$" |wc -l`
		if (( $FNDCNT > 0 ))
		then
			export DIFFCONDCNT=`expr ${DIFFCONDCNT} \+ ${FNDCNT}`
			echo "DIFFCOND:SRC:${i}:${SRHPARM}" >> /tmp/work_expand_results_${PID}
			grep "^${DIFFCONDPARM}:" /tmp/work_expand_dest_${PID} |grep ":${DIFFCONDSUFFIX}$" |awk -vitem=${i} '{print "DIFFCOND:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
			grep -v "^${DIFFCONDPARM}:"  /tmp/work_expand_dest_work_${PID} >  /tmp/work_expand_dest_work_${PID}_2
			grep "^${DIFFCONDPARM}:"  /tmp/work_expand_dest_work_${PID} |grep -v ":${DIFFCONDSUFFIX}$" >> /tmp/work_expand_dest_work_${PID}_2
			cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
			continue
		fi

		# Check for missing user only (and ignore conditions)
		export MISSUSERPARM=`echo "${SRHPARM}" |awk -F":" '{print $2":"$3}'`
		export MISSUSERSUFFIX=`echo "${SRHPARM}" |awk -F":" '{print $5}'`
		export FNDCNT=`grep ":${MISSUSERPARM}:" /tmp/work_expand_dest_${PID} |grep ":${MISSUSERSUFFIX}$" |wc -l`
		if (( $FNDCNT > 0 ))
		then	
			export MISSUSERCNT=`expr ${MISSUSERCNT} \+ ${FNDCNT}`
			echo "MISSUSER:SRC:${i}:${SRHPARM}" >> /tmp/work_expand_results_${PID}
			grep ":${MISSUSERPARM}:" /tmp/work_expand_dest_${PID} |grep ":${MISSUSERSUFFIX}$" |awk -vitem=${i} '{print "MISSUSER:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
			grep -v ":${MISSUSERPARM}:" /tmp/work_expand_dest_work_${PID} > /tmp/work_expand_dest_work_${PID}_2
			grep ":${MISSUSERPARM}:" /tmp/work_expand_dest_work_${PID} |grep -v ":${MISSUSERSUFFIX}$" >> /tmp/work_expand_dest_work_${PID}_2
			cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
			continue
		fi

		# 
		# Now at end, add $i to unallocatyede list
		export UNALLOCLIST="${UNALLOCLIST} ${i} "
	done	

	export FOUNDCNT=`expr ${MATCHCNT} \+ ${NONCONDCNT}`
	export LEFTCNT=`expr ${TOTCNT} \- ${FOUNDCNT}`

	echo "    Complete match = ${MATCHCNT}"
	grep "^MATCH:" /tmp/work_expand_results_${PID} |awk '{print " - "$0}'	
	echo
	echo "   No condition = ${NONCONDCNT}"
	grep "^NONCOND:" /tmp/work_expand_results_${PID} |awk '{print " - "$0}'	
	echo
	echo "   Diff condition = ${DIFFCONDCNT}"
	grep "^DIFFCOND:" /tmp/work_expand_results_${PID} |awk '{print " - "$0}'	
	echo
	echo "   User mismatch condition = ${MISSUSERCNT}"
	grep "^MISSUSER:" /tmp/work_expand_results_${PID} |awk '{print " - "$0}'	
	echo
	echo
	echo "	  Rest of = ${LEFTCNT} unalloclist: ${UNALLOCLIST}"
	for i in $(echo "${UNALLOCLIST}")
	do
		grep -i "^${i}:" /tmp/work_expand_source_work_${PID} |head -n 1 |awk '{print "   "$0}'
	done	
	echo
	export REMCNT=`cat /tmp/work_expand_dest_work_${PID} |wc -l`
	echo "    Unallocated $REMCNT /tmp/work_expand_dest_work_${PID}"
	echo "    Master List /tmp/work_expand_source_work_${PID}"
	echo "Return to continue"
	read
}

function compare_menu
{
	# split out and compare 
	export OPTION=""
	while [[ "${OPTION}" != [Qq] ]]
	do
		clear
		echo "             Compare files sudoers"
		echo "            ======================="
		echo

		export SRCCNT=`cat /tmp/work_expand_source_${PID} |wc -l`
		export DESTCNT=`cat /tmp/work_expand_dest_${PID} |wc -l`
		# echo "  SRC: /tmp/work_expand_source_${PID} $(SRCCNT} Lines"
		# echo " DEST: /tmp/work_expand_dest_${PID} $(DESTCNT} Lines"
		# Note: do not use echo for SRC and DEST, it can't handle something and I can't figure out what
		# Note: use printf instead
		printf "  SRC: %-30s - %i lines\n" "/tmp/work_expand_source_${PID}" ${SRCCNT}
		printf " DEST: %-30s - %i lines\n" "/tmp/work_expand_dest_${PID}" ${DESTCNT}
		echo

		# Do matchup - exact lines
		compare_files
	
		echo "Enter options"
		read	
	done

	echo
}

function expand_out_rules
{
	# Check we have a alias expand
	if [[ ! -f /tmp/work_expanded_all_alias_${PID} ]]
	then
		echo "Alias /tmp/work_expanded_all_alias_${PID} not expanded out, these are pre-reqs for rules - exiting"
		exit
	fi

	# Strip out lines (and cater for continuation)
	# cat ${SRCFILE} | awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g' > /tmp/work_line_cont_fix_${PID}
	grep -v "^Host_Alias" /tmp/work_line_cont_fix_${PID} |grep -v "^Cmnd_Alias" |grep -v "User_Alias" |grep -v "^Defaults" |awk 'NF > 0 {print $0}' |awk '{for(i=1;i<=NF;i++) printf("%s ", $i)}{printf("\n")}' |sed 's/ $//g' |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_expanded_rules_${PID}

	# Loop through rules and strip out commas
	cat /dev/null > /tmp/work_expand_rules_strip_${PID}
	for i in $(cat /tmp/work_expanded_rules_${PID} |awk -F":" '{print $1}' |sort -u)
	do
		# Strip out line and decode
		export SRCLINE=`grep "^${i}:" /tmp/work_expanded_rules_${PID} |head -n 1 |sed "s/^${i}://g"`
		export PT1=`echo "${SRCLINE}" |awk -F"=" '{print $1}'`
		export PT2=`echo "${SRCLINE}" |awk -F"=" '{print $2}'`
		export NUMF=`echo "${SRCLINE}" |awk -F"=" '{print NF}'`
		if (( $NUMF > 2 )) 
		then
			echo "improperly formatted sudoers line ${SRCLINE}" >> /tmp/work_sudoers_errfile_${PID}
			continue
		fi
		
		# Split out users and hosts
		export TGTUSERS=`echo "${PT1}" |awk '{print $1}'`
		export TGTHOSTS=`echo "${PT1}" |awk '{print $2}'`
		export NUMF=`echo "${PT1}" |awk '{print NF}'`
		if (( $NUMF != 2 ))
		then
			echo "too many fields before = ${PT1}" >> /tmp/work_sudoers_errfile_${PID}
			continue
		fi

		# Strip out user defined
		export USERRULE=""
		export RESTRULE="${PT2}"
		export USERDEF=`echo "${PT2}" |awk '{print substr($1, 1, 1)}'`
		if [[ "${USERDEF}" == "(" ]]
 		then
			export USERRULE=`echo "${PT2}" |sed 's/)/ /g' |sed 's/(/ /g' |awk '{print $1}'`
			export RESTRULE=`echo "${PT2}" |sed 's/)/ /g' |sed 's/(/ /g' |awk '{for(i=2;i<=NF;i++) printf("%s ", $i)} {printf("\n")}' |sed 's/ $//g'`
		fi

		# Strip out PASSWD and EXEC conditions
		export COLCNT=`echo "${PT2}" |grep -i ":" |wc -l`
		export COND=""
		export CMDRULE=""
		if (( $COLCNT > 0 ))
		then
			# Strip out conditions	
			export COND=`echo "${RESTRULE}" |awk -F":" '{for(i=1;i<NF;i++) printf("%s~", $i)}'`
			export CMDRULE=`echo "${RESTRULE}" |awk -F":" '{print $NF}'`
		else
			export CMDRULE="${RESTRULE}"
		fi
	
		# Strip out command rule
		echo "${CMDRULE}" |awk -F"," '{for(i=1;i<=NF;i++) printf("%s\n", $i)}' |sed 's/^ //g' > /tmp/work_expanded_onlyrules_${PID}
	
		# Loop through and generate full file - users, hosts, commands
		for j in $(echo "${TGTUSERS}")
		do
			for k in $(echo "${TGTHOSTS}")
			do
				# Cat the users, hosts and commands
				cat /tmp/work_expanded_onlyrules_${PID} |awk -vusers=${j} -vhosts=${k} -vurule=${USERRULE} -vcond=${COND} '{print users":"hosts":"urule":"cond":"$0}' >> /tmp/work_expand_rules_strip_${PID}
			done
		done
		echo "${SRCLINE} - breakdown"
		echo "TYarget users ${TGTUSERS}"
		echo "Target hosts ${TGTHOSTS}"
		echo "User rule ${USERRULE}"
		echo "Condition ${COND}"
		echo "Command rule ${CMDRULE}"
		echo "--------------"
	done

	# Now loop through and gather host aliases
	cat /tmp/work_expand_rules_strip_${PID} |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_expand_rules_work_${PID}
	
	echo "First expand completed"
	# ls -al /tmp/work_expand_rules_strip_${PID} 
	# cat /tmp/work_expand_rules_strip_${PID}

	echo "Now expand target users"
	cat /dev/null > /tmp/work_expand_rules_temp_${PID}
	for i in $(cat /tmp/work_expand_rules_work_${PID} |awk -F":" '{print $1}' |sort -u)
	do
		# Read in line
		export LINE1=`grep "^${i}:" /tmp/work_expand_rules_work_${PID} |head -n 1`
		export SRHUSER=`echo "${LINE1}" |awk -F":" '{print $2}'`
		export REMAINDER=`echo "${LINE1}" |awk -F":" '{print $3":"$4":"$5":"$6}'`

		# Find occurences of User alias in /tmp/work_expanded_all_alias_${PID}
		export FNDCNT=`grep "^User_Alias:${SRHUSER}:" /tmp/work_expanded_all_alias_${PID} |wc -l`
		if (( $FNDCNT < 1 ))
		then
			# No user swaps, just add line to outfile
			echo "${SRHUSER}:${REMAINDER}" >> /tmp/work_expand_rules_temp_${PID}
		else
			# add all entries for user to outfile
			grep "^User_Alias:${SRHUSER}:" /tmp/work_expanded_all_alias_${PID} |awk -F":" -vremain="${REMAINDER}" '{print $3":"remain}' >> /tmp/work_expand_rules_temp_${PID}
		fi

	done

	# Now copy back and start on host alias
	cat /tmp/work_expand_rules_temp_${PID} |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_expand_rules_work_${PID}
	cat /dev/null > /tmp/work_expand_rules_temp_${PID}
	for i in $(cat /tmp/work_expand_rules_work_${PID} |awk -F":" '{print $1}' |sort -u)
	do
		# Read in line
		export LINE1=`grep "^${i}:" /tmp/work_expand_rules_work_${PID} |head -n 1`
		export ORIGUSER=`echo "${LINE1}" |awk -F":" '{print $2}'`
		export SRHHOST=`echo "${LINE1}" |awk -F":" '{print $3}'`
		export REMAINDER=`echo "${LINE1}" |awk -F":" '{print $4":"$5":"$6}'`

		# Find occurences of User alias in /tmp/work_expanded_all_alias_${PID}
		export FNDCNT=`grep "^Host_Alias:${SRHHOST}:" /tmp/work_expanded_all_alias_${PID} |wc -l`
		if (( $FNDCNT < 1 ))
		then
			# No user swaps, just add line to outfile
			echo "${ORIGUSER}:${SRHHOST}:${REMAINDER}" >> /tmp/work_expand_rules_temp_${PID}
		else
			# add all entries for user to outfile
			grep "^Host_Alias:${SRHHOST}:" /tmp/work_expanded_all_alias_${PID} |awk -F":" -vsrhuser=${ORIGUSER} -vremain="${REMAINDER}" '{print srhuser":"$3":"remain}' >> /tmp/work_expand_rules_temp_${PID}

		fi
	done

	# Now copy back and start on command alias
	cat /tmp/work_expand_rules_temp_${PID} |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_expand_rules_work_${PID}
	cat /dev/null > /tmp/work_expand_rules_temp_${PID}

	for i in $(cat /tmp/work_expand_rules_work_${PID} |awk -F":" '{print $1}' |sort -u)
	do
		# Read in line
		export LINE1=`grep "^${i}:" /tmp/work_expand_rules_work_${PID} |head -n 1`
		export ORIGUSERHOST=`echo "${LINE1}" |awk -F":" '{print $2":"$3":"$4":"$5}'`
		export SRHCOMMAND=`echo "${LINE1}" |awk -F":" '{print $6}'`

		# Skip if more than 1 word, as will be literal command
		export WCNT=`echo "${SRHCOMMAND}" |awk '{print NF}'`
		if (( $WCNT > 1 ))
		then
			echo "${ORIGUSERHOST}:${SRHCOMMAND}" >> /tmp/work_expand_rules_temp_${PID}
			continue
		fi
		# Find occurences of User alias in /tmp/work_expanded_all_alias_${PID}
		export FNDCNT=`grep "^Cmnd_Alias:${SRHCOMMAND}:" /tmp/work_expanded_all_alias_${PID} |wc -l`
		if (( $FNDCNT < 1 ))
		then
			# No user swaps, just add line to outfile
			echo "${ORIGUSERHOST}:${SRHCOMMAND}" >> /tmp/work_expand_rules_temp_${PID}
		else
			# add all entries for user to outfile
			grep "^Cmnd_Alias:${SRHCOMMAND}:" /tmp/work_expanded_all_alias_${PID} |awk -F":" -vsrhuser=${ORIGUSERHOST} '{print srhuser":"$3}' >> /tmp/work_expand_rules_temp_${PID}

		fi
	done
	echo "Final expand completed"
	ls -al /tmp/work_expand_rules_temp_${PID}
}

function expand_out_alias
{

# Strip out Host Alias - wrap file around for line continuation
grep "^${TGTALIAS}" /tmp/work_line_cont_fix_${PID} |sed "s/${TGTALIAS}//g" |awk '{for(i=1;i<=NF;i++) printf("%s ", $i)}{printf("\n")}' |sed 's/ $//g' >  /tmp/work_alias_${PID}
cat /tmp/work_alias_${PID} |sed 's/=/,/g' |awk -F"," '{name=$1}{for(i=2;i<=NF;i++) printf("%s:%s\n", name, $i)}' |sed 's/^ //g' |sed 's/: /:/g'  |sed 's/ :/:/g' > /tmp/work_host_alias_${PID}

# Strip out lines with more than 1 column, these are commands and do not need to be tracked
cat /tmp/work_host_alias_${PID} |awk 'NF > 1 {print $0}' > /tmp/work_host_alias_save_${PID}
cat /tmp/work_host_alias_${PID} |awk 'NF == 1 {print $0}' > /tmp/work_host_alias_trim_${PID} 
cp /tmp/work_host_alias_trim_${PID} /tmp/work_host_alias_new_${PID}

# Loop around
# export NEWLNCOUNT=0
# export LNCOUNT=`cat /tmp/work_host_alias_trim_${PID} |wc -l`
export LNCOUNT=0
export NEWLNCOUNT=`cat /tmp/work_host_alias_trim_${PID} |wc -l`
while (( $LNCOUNT < $NEWLNCOUNT ))
do
	# Create work file and 
	cp /tmp/work_host_alias_new_${PID} /tmp/work_host_alias_trim_${PID}

	cat /dev/null > /tmp/work_host_alias_new_${PID}
	cp /tmp/work_host_alias_trim_${PID} /tmp/work_host_alias_work_${PID}
	export LNCOUNT=`cat /tmp/work_host_alias_trim_${PID} |wc -l`
	export WORKLNCOUNT=`cat /tmp/work_host_alias_work_${PID} |wc -l`
	while (( $WORKLNCOUNT > 0 ))
	do
		# Find occurences
		export LINE1=`head -n 1 /tmp/work_host_alias_work_${PID}`
		export SRCGROUP=`echo "${LINE1}" |awk -F":" '{print $1}'`
		export TGTGROUP=`echo "${LINE1}" |awk -F":" '{print $2}'`
		export USECNT1=`grep "^${TGTGROUP}:" /tmp/work_host_alias_trim_${PID} |wc -l`
		export USECNT2=`grep "^${TGTGROUP}:" /tmp/work_host_alias_save_${PID} |wc -l`
		if (( $USECNT1 > 0 ))
		then
			# add in replacement entries
			grep -i "^${TGTGROUP}:" /tmp/work_host_alias_trim_${PID} |awk -vsrc=${SRCGROUP} -F":" '{print src":"$2}' >> /tmp/work_host_alias_new_${PID}
		elif (( $USECNT2 > 0 ))
		then
			grep -i "^${TGTGROUP}:" /tmp/work_host_alias_save_${PID} |awk -vsrc=${SRCGROUP} -F":" '{print src":"$2}' >> /tmp/work_host_alias_new_${PID}
		else
			echo "${LINE1}" >> /tmp/work_host_alias_new_${PID}
		fi

		grep -v "^${LINE1}$" /tmp/work_host_alias_work_${PID} > /tmp/work_host_alias_work_${PID}_2
		cp /tmp/work_host_alias_work_${PID}_2 /tmp/work_host_alias_work_${PID}
		export WORKLNCOUNT=`cat /tmp/work_host_alias_work_${PID} |wc -l`

	done < /tmp/work_host_alias_work_${PID}

	# Confirm before and after
	export NEWLNCOUNT=`cat /tmp/work_host_alias_new_${PID} |wc -l`
	echo "Before LNCOUNT ${LNCOUNT} After LNCOUNT ${NEWLNCOUNT} - return to continue"
# 	ls -al /tmp/work_host_alias_trim_${PID} /tmp/work_host_alias_new_${PID}
#	read		
done

# Append /tmp/work_host_alias_save_${PID}
echo "results - append saved entries"
cat /tmp/work_host_alias_save_${PID} >>  /tmp/work_host_alias_new_${PID}
cat /tmp/work_host_alias_new_${PID}
cat /tmp/work_host_alias_new_${PID} |awk -vsrc=${TGTALIAS} '{print src":"$0}' >> /tmp/work_expanded_all_alias_${PID}

}

function regen_extracts
{
# update figures for checksum
export ORIGSUM=`sum ${ORIGFILE} |awk '{print $1"_"$2}'`
grep -v "^ORIGSUM:" ${CFGFILE} > ${CFGFILE}_2
echo "ORIGSUM:${ORIGSUM}" >> ${CFGFILE}_2
cp ${CFGFILE}_2 ${CFGFILE}

cat /dev/null > /tmp/work_sudoers_errfile_${PID}
cat /dev/null > /tmp/work_expanded_all_alias_${PID}
cat ${ORIGFILE} | awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g' > /tmp/work_line_cont_fix_${PID}
export TGTALIAS="Host_Alias"
expand_out_alias
export TGTALIAS="Cmnd_Alias"
expand_out_alias
export TGTALIAS="User_Alias"
expand_out_alias

# Now find rules and create rules list (cater for line wrap)
expand_out_rules

cp /tmp/work_expand_rules_temp_${PID} /tmp/work_expand_source_${PID}

# AAA - check
echo "half expand - check /tmp/work_expand_source_${PID} /tmp/work_expanded_all_alias_${PID}"
read
# Now do for second set of files
export NEWSUM=`sum ${NEWFILE} |awk '{print $1"_"$2}'`
grep -v "^NEWSUM:" ${CFGFILE} > ${CFGFILE}_2
echo "NEWSUM:${NEWSUM}" >> ${CFGFILE}_2
cp ${CFGFILE}_2 ${CFGFILE}

cat /dev/null > /tmp/work_expanded_all_alias_${PID}
cat ${NEWFILE} | awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g' > /tmp/work_line_cont_fix_${PID}
export TGTALIAS="Host_Alias"
expand_out_alias
export TGTALIAS="Cmnd_Alias"
expand_out_alias
export TGTALIAS="User_Alias"
expand_out_alias
 
# # Now find rules and create rules list (cater for line wrap)
expand_out_rules
 
cp /tmp/work_expand_rules_temp_${PID} /tmp/work_expand_dest_${PID}

# UPdate regen date
export REGDATE=`date`
grep -v "^LASTREGEN~" ${CFGFILE} > ${CFGFILE}_2
echo "LASTREGEN~${REGDATE}" >> ${CFGFILE}_2
cp ${CFGFILE}_2 ${CFGFILE}

# echo "ALL DONE"
# echo "========="
ls -al /tmp/work_expand_source_${PID} /tmp/work_expand_dest_${PID}
# compare_menu
# 
# # Now match up correct matches, those that only miss match on conditions, then different for equiv user, then host, then actual user, then command
# # (exclude previous rules as you go down)
}

# NEW MAIN GROUP
export PARM=$*
export HNAME=`hostname -s`
if [[ $HNAME == "rhel7dsms" ]]
then
	export CFGFILE=/home/fred/compare_sudoers.cfg
else
	export CFGFILE=/home/idza59/DSMS/compare_sudoers.cfg
fi
if [[ ! -f "${CFGFILE}" ]]
then
	touch $CFGFILE
fi
# Load 
export OPTION=""
while [[ "${OPTION}" != [QqXx] ]]
do
	# Main menu
	clear
	echo "              Compare Sudoers"
	echo "             ================="
	echo

	# print menu	
	export ORIGFILE=`grep "^ORIGFILE:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	export NEWFILE=`grep "^NEWFILE:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	export ORIGSUM=`grep "^ORIGSUM:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	export NEWSUM=`grep "^NEWSUM:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	if [[ "${ORIGFILE}" != "" ]]
	then
		export CURRORIGSUM=`sum ${ORIGFILE} |awk '{print $1"_"$2}'`
	else
		export CURRORIGSUM="XXXX"
	fi
	if [[ "${NEWFILE}" != "" ]]
	then
		export CURRNEWSUM=`sum ${NEWFILE} |awk '{print $1"_"$2}'`
		if [[ ${CURRNEWSUM} != ${NEWSUM} ]]
		then
			export SUMFLAG="*****"
		else
			export SUMFLAG=""
		fi
	else
		export CURRNEWSUM="XXXX"
		export SUMFLAG="NA"
	fi
	printf "   Orig file: %-30s GenSum: %-12s   Current Sum %-12s\n" ${ORIGFILE} ${ORIGSUM} ${CURRORIGSUM}
	printf "    New file: %-30s GenSum: %-12s   Current Sum %-12s  Status: %s\n" ${NEWFILE} ${NEWSUM} ${CURRNEWSUM} "${SUMFLAG}"

	# Output stats - last regen, last checksums (and change in checksum)
	export LASTREGEN=`grep "^LASTREGEN~"  ${CFGFILE} |head -n 1 |awk -F"~" '{print $2}'`
	echo   "   Last Regen: ${LASTREGEN}"
	echo
	# Output options
	echo "     R. Regen extracts"
	echo "     D. Analysis Defaults"
	echo "     A. Analysis Rules"
	
	echo "      F. Enter Filenames"
	echo

	echo

	printf "    Enter option:"
	read OPTION

	case "${OPTION}" in
	[Ff]) enter_filenames ;;
	[Rr]) regen_extracts ;;
	[Aa]) analysis_extracts ;;
	[Dd]) analysis_defaults ;;
	*) ;;
	esac
done

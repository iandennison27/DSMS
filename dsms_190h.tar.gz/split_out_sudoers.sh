#!/bin/bash

# Script name: split_out_sudoers.sh
# Script Author: Ian Dennison (idza59)
#
# Release schedule:
# v1.0.9f.1 - Reformat output information into columns (30 Aug 2022)
# v1.0.9f.2 - Correct search for * parameters (7 Sep 2022)
# v1.0.9f.3 - Match Hostname against "ALL" and vice-versa, allow condition match and mismatch as well. (28 Sep 2022)
# v1.0.9f.4 - restrict source output to system groups, "ALL" and the current hostname (2 Oct 2022)
# v1.0.9f.5 - allow for multi-level expandable aliases (5 Oct 2022)

# script to expand out sudoers
export SRCFILE=test2

function show_history
{
	echo
	echo " Date             | Host       |Match | Default | Host | CondHost | Cond | User | nomatch"
	cat ${HISTFILE} |awk -F":" '{printf(" %-15s   %-12s  %3i     %3i      %3i      %3i      %3i     %3i    %3i\n", $1, $2, $3, $4, $5, $6, $7, $8, $9)}'
	read
}

function output_conditional_format
{
	# Output Conditional values
	echo "     MATCH LINES"
	echo "     1. Direct match Lines                        : ${MATCHCNT} entries"
	if (( $MATCHSHOW == 1 ))
	then
		export TGTENTRY="MATCH"
		format_output
		echo
	fi
	echo "     2. Empty or default condition                : ${DEFCONDCNT} entries"
	if (( $DEFAULTSHOW == 1 ))
	then
	 	export TGTENTRY="DEFAULTCOND"
 		format_output
	 	echo
	fi
	echo "     3. Hostname equivalent and condition match   : ${MATCHHOSTCNT} entries"
	if (( $EQUIVSHOW == 1 ))
	then
	 	export TGTENTRY="MATCHHOST"
 		format_output
	 	echo
	fi
	echo
	echo "     MIS-MATCH LINES"
	echo "     4. Hostname equivalent, condition mismatch   : ${MATCHHOSTCONDCNT} entries"
	if (( $CONDHOSTSHOW == 1 ))
	then
	 	export TGTENTRY="MATCHHOSTCOND"
 		format_output
	 	echo
	fi
	echo "     5. Different Condition                       : ${DIFFCONDCNT} entries"
	if (( $CONDSHOW == 1 ))
	then
	 	export TGTENTRY="DIFFCOND"
 		format_output
	 	echo
	fi
	echo "     6. User mismatch			          : ${MISSUSERCNT} entries"
	if (( $USERSHOW == 1 ))
	then
	 	export TGTENTRY="USERCOND"
 		format_output
	 	echo
	fi
	echo "     7. Totally unmatched		 	  : ${LEFTCNT} entries"
	if (( $NONESHOW == 1 ))
	then
	 	export TGTENTRY="NOMATCH"
 		format_output
	 	echo
	fi

}

function analyse_format
{
	# Check out option
	echo "OPTION = $OPTION"
	if [[ ${OPTION} == "1" ]]
	then
		# Flip flag
		if (( $MATCHSHOW == 1 ))
		then
			export MATCHSHOW=0
		else
			export MATCHSHOW=1
		fi	
	fi
	if [[ ${OPTION} == "2" ]]
	then
		# Flip flag
		if (( $DEFAULTSHOW == 1 ))
		then
			export DEFAULTSHOW=0
		else
			export DEFAULTSHOW=1
		fi	
	fi
	if [[ ${OPTION} == "3" ]]
	then
		# Flip flag
		if (( $EQUIVSHOW == 1 ))
		then
			export EQUIVSHOW=0
		else
			export EQUIVSHOW=1
		fi	
	fi
	if [[ ${OPTION} == "4" ]]
	then
		# Flip flag
		if (( $CONDHOSTSHOW == 1 ))
		then
			export CONDHOSTSHOW=0
		else
			export CONDHOSTSHOW=1
		fi	
	fi
	if [[ ${OPTION} == "5" ]]
	then
		# Flip flag
		if (( $CONDSHOW == 1 ))
		then
			export CONDSHOW=0
		else
			export CONDSHOW=1
		fi	
	fi
	if [[ ${OPTION} == "6" ]]
	then
		# Flip flag
		if (( $USERSHOW == 1 ))
		then
			export USERSHOW=0
		else
			export USERSHOW=1
		fi	
	fi
	if [[ ${OPTION} == "7" ]]
	then
		# Flip flag
		if (( $NONESHOW == 1 ))
		then
			export NONESHOW=0
		else
			export NONESHOW=1
		fi	
	fi

}

function format_output
{
	if [[ "${TGTENTRY}" == "" ]]
	then
		echo "No target entry - continuing"
		return
	fi

	export FNDCNT=`grep "^${TGTENTRY}:" /tmp/work_expand_results_${PID}  |wc -l`
	if (( $FNDCNT < 1 ))
	then
		echo "  No entries found"
		return
	fi
	# Get numbers and SRC/DEST
        echo "  Seq | Src  |Userid              | Host               | User               | Conditional        | Command "
        echo "======+======+====================+====================+====================+====================+================="

	for i in $(grep "^${TGTENTRY}:" /tmp/work_expand_results_${PID} |awk -F":" '{print $3}' |sort -n -u)
	do
		# Split out gathering command as well
		export SRCCMD=`grep -i "^${TGTENTRY}:SRC:${i}:" /tmp/work_expand_results_${PID} |awk -F":" '{for(i=8;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`
		grep -i "^${TGTENTRY}:SRC:${i}:" /tmp/work_expand_results_${PID} |awk -F":" '{printf(" - %3i:%-5s :%-20s:%-20s:%-20s:%-20s:", $3, $2, $4, $5, $6, $7)}'
		printf "%s\n" "${SRCCMD}"

		export DESTCMD=`grep -i "^${TGTENTRY}:DEST:${i}:" /tmp/work_expand_results_${PID} |awk -F":" '{for(i=8;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`
		grep -i "^${TGTENTRY}:DEST:${i}:" /tmp/work_expand_results_${PID} |awk -F":" '{printf(" - %3i:%-5s :%-20s:%-20s:%-20s:%-20s:", $3, $2, $4, $5, $6, $7)}'
		printf "%s\n" "${DESTCMD}"

		# export REMAINDER=`echo "${LINE1}" |awk -F":" '{for(i=3;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`
		# grep -i "^${TGTENTRY}:SRC:${i}:" /tmp/work_expand_results_${PID} |awk -F":" '{printf(" - %3i:%-5s :%-20s:%-20s:%-20s:%-20s:%s\n", $3, $2, $4, $5, $6, $7, $8)}'
		# grep -i "^${TGTENTRY}:DEST:${i}:" /tmp/work_expand_results_${PID} |awk -F":" '{printf(" - %3i:%-5s :%-20s:%-20s:%-20s:%-20s:%s\n", $3, $2, $4, $5, $6, $7, $8)}'
		echo "----------------------------------------------"
	done

}

function search_file
{
	printf "Enter search term:"
	read SRH
	if [[ "${SRH}" == "" ]]
	then
		return
	fi

	# Loop through ORIGFILE
	printf "\n"
	for i in $(echo "${ORIGFILE}")
	do
		printf "File ${i}:"
		grep -i "${SRH}" ${i}
		printf "\n"
	done
	echo "Return to continue"
	read 

}


function cat_file
{
	printf "Enter filename:"
	read FNAME
	if [[ "${FNAME}" == "" ]]
	then
		return
	fi

	# look for filename
	export TGTFILE=""
	for i in $(echo "${ORIGFILE}")
	do
		export FNDCNT=`echo "${i}" |grep -i ${FNAME} |wc -l`
		if (( $FNDCNT > 0 ))
		then
			export TGTFILE="${i}"
			break
		fi
	done

	# Check fnamne
	if [[ "${TGTFILE}" == "" ]]
	then
		echo "No match - return to cotninue"
		read
		return
	fi

	# Cat file 
	echo
	echo "XXXXXXXXXXXXX"
	cat ${TGTFILE} |awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" || $1 == "#includedir" {print $0}'

	echo
	echo "OK Rturn to cotninue"
	read

}

function enter_filenames
{
	# Enter original and new file - change to allow multiples
	export ORIGFILE=`grep "^ORIGFILE:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	export SRCHOST=`grep "^SRCHOST:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	printf "  Original File: %s\n" "${ORIGFILE}"
	printf "    Enter File name:"
	read NEWORIG
	if [[ "${NEWORIG}" != "" ]]
	then
		export NEWLIST=""	
		# Check if directory
		if [[ -d ${NEWORIG} ]]
		then
			 # Build up based on directory
			if [[ -f ${NEWORIG}/sudoers ]]
			then
				export NEWLIST="${NEWLIST} ${NEWORIG}/sudoers"
			fi
			if [[ -d ${NEWORIG}/sudoers.d ]]
			then
				# Loop through and add files
				for i in $(ls -A ${NEWORIG}/sudoers.d)
				do
					if [[ ${i} != "table_of_contents" ]]
					then
						if [[ -f ${NEWORIG}/sudoers.d/${i} ]]
						then
							# Check if text
							export FTYPE=`file ${NEWORIG}/sudoers.d/${i} |grep -i ASCII |wc -l`
							if (( $FTYPE > 0 ))
							then
								export NEWLIST="${NEWLIST} ${NEWORIG}/sudoers.d/${i}"	
							fi	
						fi
					fi
				done
			fi
		fi	
		if [[ "${NEWLIST}" == "" ]]
		then
			if [[ ! -f ${NEWORIG} ]]
			then
				echo "Not a valid filename - return to continue"
				read
			else
				export NEWLIST="${NEWORIG}"
			fi
		fi
		grep -v "ORIGFILE:" ${CFGFILE} > ${CFGFILE}_2
		echo "ORIGFILE:${NEWLIST}" >> ${CFGFILE}_2
		cp ${CFGFILE}_2 ${CFGFILE}

		# prompt for hostname
		printf "  Current source hostname: %s\n" ${SRCHOST}
		printf "  Enter source hostname:" 
		read NEWHOST
		if [[ "${NEWHOST}" != "" ]]
		then
			grep -v "SRCHOST:" ${CFGFILE} > ${CFGFILE}_2
			echo "SRCHOST:${NEWHOST}" >> ${CFGFILE}_2
			cp ${CFGFILE}_2 ${CFGFILE}
		fi
	fi
	export NEWFILE=`grep "^NEWFILE:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	printf "  New File: %s\n" "${NEWFILE}"
	printf "    Enter File name:"
	read NEWNEW
	if [[ "${NEWNEW}" != "" ]]
	then
		if [[ ! -f ${NEWNEW} ]]
		then
			echo "Not a valid filename - return to continue"
			read
		else
			grep -v "NEWFILE:" ${CFGFILE} > ${CFGFILE}_2
			echo "NEWFILE:${NEWNEW}" >> ${CFGFILE}_2
			cp ${CFGFILE}_2 ${CFGFILE}
		fi
	fi

}

function analysis_defaults
{
	# Analyse the defaults - generate extracts
	cat /dev/null > /tmp/work_defaults_warn_${PID}
	echo " Analysing defaults - source ${ORIGFILE}"
	cat ${ORIGFILE} | sed "s/=/ = /g" |sed "s/+ =/ += /g" |awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g' |grep "^Defaults" > /tmp/work_defaults_source_${PID}
	cat /tmp/work_defaults_source_${PID}
	echo " Analysing defaults - dest ${NEWFILE}"
	cat ${NEWFILE} | sed "s/=/ = /g" |sed "s/+ =/ += /g" | awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g'  |grep "^Defaults" > /tmp/work_defaults_dest_${PID}
	cat  /tmp/work_defaults_dest_${PID}
	
	# Strip out secure path 
	echo "Examine defaults"
	grep "Defaults" /tmp/work_defaults_source_${PID} |awk '$2 == "secure_path" {print $0}' |awk -F"=" '{for(i=2;i<=NF;i++) {printf("%s=", $i)}}{printf "\n"}' |sed 's/=$//g' |sed 's/"//g' |sed 's/:/ /g' |awk '{for(i=1;i<=NF;i++) {printf("ORIG:%s\n", $i)}}' > /tmp/work_defaults_source_secure_${PID}
	export ORIGCNT=`cat /tmp/work_defaults_source_secure_${PID} |wc -l`
	if (( $ORIGCNT < 1 ))
	then
		echo "ORIG:" >> /tmp/work_defaults_dest_secure_${PID}
	fi
		
	grep "Defaults" /tmp/work_defaults_dest_${PID} |awk '$2 == "secure_path" {print $0}' |awk -F"=" '{for(i=2;i<=NF;i++) {printf("%s=", $i)}}{printf "\n"}' |sed 's/=$//g' |sed 's/"//g' |sed 's/:/ /g' | awk '{for(i=1;i<=NF;i++) {printf("NEW:%s\n", $i)}}'  > /tmp/work_defaults_dest_secure_${PID}
	export NEWCNT=`cat /tmp/work_defaults_dest_secure_${PID} |wc -l`
	if (( $NEWCNT < 1 ))
	then
		echo "NEW:" >> /tmp/work_defaults_dest_secure_${PID}
	fi
	# Loop around showing securepath results
	cat  /tmp/work_defaults_source_secure_${PID} >  /tmp/work_defaults_source_both_${PID}
	cat /tmp/work_defaults_dest_secure_${PID} >> /tmp/work_defaults_source_both_${PID}

	printf " Secure_Path  |"	
	for i in $(cat  /tmp/work_defaults_source_both_${PID} |awk -F":" '{print $1}' |sort -ur)
	do
		printf " %-12s |" ${i}
	done
	printf "\n==============+==============+==============+\n"

	for i in $(cat /tmp/work_defaults_source_both_${PID} |awk -F":" '{print $2}' |awk 'NF > 0 {print $1}' |sort -u)	
	do
		printf " %-12s |" ${i}
	
		for j in $(cat /tmp/work_defaults_source_both_${PID} |awk -F":" '{print $1}' |sort -ur)
		do
			export FNDCNT=`grep "^${j}:${i}$" /tmp/work_defaults_source_both_${PID} |wc -l`
			if (( $FNDCNT < 1 ))
			then
				printf "      -       |"
			else
				printf "      X       |"
			fi
		done
		printf "\n"

	done

	# Strip out environment variables, strip out after env_reset (sequence is important)
	echo
	echo "Examine environment"
	grep "Defaults" /tmp/work_defaults_source_${PID} |awk '$2 == "env_keep" || $2 == "env_reset" {print $0}' |sed 's/env_keep=/env_keep = /g' |sed 's/env_keep+=/env_keep += /g' |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_defaults_source_env_${PID}
	export LASTORIGRESET=`grep "env_keep" /tmp/work_defaults_source_env_${PID} |awk '$3 == "=" {print $0}' |tail -n 1 |awk -F":" '{print $1}'`
	export REGLIST=`cat /tmp/work_defaults_source_env_${PID} |awk -F":" -vstartseq=${LASTORIGRESET} '$1 >= startseq {printf("%s ", $1)}'`

	cat /dev/null > /tmp/work_defaults_combined_env_trim_${PID}	
	for i in $(echo "${REGLIST}")
	do
		grep "^${i}:" /tmp/work_defaults_source_env_${PID} |sed "s/^${i}://g" | awk -F"=" '{for(i=2;i<=NF;i++) {printf("%s=", $i)}}{printf "\n"}' |sed 's/=$//g' |sed 's/"//g' |awk '{for(i=1;i<=NF;i++) {printf("ORIG:%s\n", $i)}}'>> /tmp/work_defaults_combined_env_trim_${PID}
	done
	
	grep "Defaults" /tmp/work_defaults_dest_${PID} |awk '$2 == "env_keep" || $2 == "env_reset" {print $0}' |sed 's/env_keep=/env_keep = /g' |sed 's/env_keep+=/env_keep += /g' |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_defaults_dest_env_${PID}
	export LASTNEWESET=`grep "env_keep" /tmp/work_defaults_dest_env_${PID} |awk '$3 == "=" {print $0}' |tail -n 1 |awk -F":" '{print $1}'`
	export REGLIST=`cat /tmp/work_defaults_dest_env_${PID} |awk -F":" -vstartseq=${LASTONEWRESET} '$1 >= startseq {printf("%s ", $1)}'`

	for i in $(echo "${REGLIST}")
	do
		grep "^${i}:" /tmp/work_defaults_dest_env_${PID} |sed "s/^${i}://g" | awk -F"=" '{for(i=2;i<=NF;i++) {printf("%s=", $i)}}{printf "\n"}' |sed 's/=$//g' |sed 's/"//g' |awk '{for(i=1;i<=NF;i++) {printf("NEW:%s\n", $i)}}'>> /tmp/work_defaults_combined_env_trim_${PID}
	done

	# List out environment defaults
	printf "\n"
	printf " Environment          |"	
	for i in $(cat  /tmp/work_defaults_combined_env_trim_${PID} |awk -F":" '{print $1}' |sort -ur)
	do
		printf " %-12s |" ${i}
	done
	printf "\n======================+==============+==============+\n"

	# Loop through components"
	for i in $(cat /tmp/work_defaults_combined_env_trim_${PID} |awk -F":" '{print $2}' |sort -u)
	do
		# output environment variable
		printf " %-20s |" ${i}
		for j in $(cat  /tmp/work_defaults_combined_env_trim_${PID} |awk -F":" '{print $1}' |sort -ur)
		do
			export FNDCNT=`grep "^${j}:${i}$" /tmp/work_defaults_combined_env_trim_${PID} |wc -l`
			if (( $FNDCNT > 0 ))
			then
				printf "       X      |"
			else
				printf "       -      |"
			fi
		done
		printf "\n"
	done

	# Strip out all others defaults 
	cat /tmp/work_defaults_source_${PID} |awk '$2 != "env_reset" && $2 != "env_keep" && $2 != "secure_path" {print $0}' > /tmp/work_defaults_source_other_${PID}
	cat /tmp/work_defaults_dest_${PID} |awk '$2 != "env_reset" && $2 != "env_keep" && $2 != "secure_path" {print $0}' > /tmp/work_defaults_dest_other_${PID}
	
	# Loop around finding defaults
	cat /dev/null > /tmp/work_defaults_combined_${PID}
	export FNDCNT=`cat /tmp/work_defaults_source_other_${PID} |wc -l`
	if (( $FNDCNT < 1 ))
	then
		echo "ORIG:" >> /tmp/work_defaults_combined_${PID}
	else
		cat /tmp/work_defaults_source_other_${PID} |awk '{print "ORIG:"$0}'> /tmp/work_defaults_combined_${PID}	
	fi
	export FNDCNT=`cat /tmp/work_defaults_dest_other_${PID} |wc -l`
	if (( $FNDCNT < 1 ))
	then
		echo "DEST:" >> /tmp/work_defaults_combined_${PID}
	else
		cat /tmp/work_defaults_dest_other_${PID} |awk '{print "NEW:"$0}' >> /tmp/work_defaults_combined_${PID}
	fi

	# Loop around displaying titles
	printf "\n\n"
	printf " Other Defaults                                                         |"
	for i in $(cat /tmp/work_defaults_combined_${PID} |awk -F":" '{print $1}' |sort -ru)
	do
		printf " %-9s |" ${i}
	done
	printf "\n"
	printf "========================================================================+===========+===========+\n"

	cat /tmp/work_defaults_combined_${PID} |sed 's/ $//g' |sort > /tmp/work_defaults_combined_sort_${PID} 
	export LNCOUNT=`cat /tmp/work_defaults_combined_sort_${PID} |wc -l`
	while (( $LNCOUNT > 0 ))
	do
		# Grab line1
		export LINE1=`head -n 1 /tmp/work_defaults_combined_sort_${PID}`
		export SRHPARM=`echo "${LINE1}" |sed 's/^ORIG://g' |sed 's/^NEW://g'`

		printf " %-70s |" "${SRHPARM}:"		
		for i in $(cat /tmp/work_defaults_combined_${PID} |awk -F":" '{print $1}' |sort -ru)
		do
			export FNDCNT=`grep "^${i}:${SRHPARM}$" /tmp/work_defaults_combined_sort_${PID} |wc -l`
			if (( $FNDCNT < 1 ))
			then
				printf "     -     |"
			else
				printf "     X     |"
			fi
		done
		printf "\n"
		grep -v ":${SRHPARM}$" /tmp/work_defaults_combined_sort_${PID} > /tmp/work_defaults_combined_sort_${PID}_2
		cp /tmp/work_defaults_combined_sort_${PID}_2 /tmp/work_defaults_combined_sort_${PID}
		export LNCOUNT=`cat /tmp/work_defaults_combined_sort_${PID} |wc -l`
	done
	ls -al /tmp/work_defaults_source_other_${PID} /tmp/work_defaults_dest_other_${PID}
	echo "Return to continue"
	read
}

function analysis_extracts
{
	# Find matching lines
	cat /tmp/work_expand_source_${PID} |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_expand_source_work_${PID}
	cp /tmp/work_expand_dest_${PID} /tmp/work_expand_dest_work_${PID}

	cat /dev/null > /tmp/work_expand_results_${PID}
	export TOTCNT=`cat  /tmp/work_expand_source_work_${PID} |wc -l`
	export MATCHCNT=0
	export DEFCONDCNT=0
	export MATCHHOSTCNT=0
	export MATCHHOSTCONDCNT=0
	export NONCONDCNT=0
	export DIFFCONDCNT=0
	export MISSUSERCNT=0
	export UNALLOCLIST=""

	printf "\n"	
	for i in $(cat /tmp/work_expand_source_work_${PID} |awk -F":" '{print $1}')
	do
		# Strip out search param - add asterisk code
		export SRHLINE=`grep "^${i}:" /tmp/work_expand_source_work_${PID} |head -n 1 |sed "s/^${i}://g"`
		export SRHPARM=`grep "^${i}:" /tmp/work_expand_source_work_${PID} |head -n 1 |sed "s/^${i}://g" |sed 's/\*/\\\*/g' |sed 's/\[/\\\[/g'`
		export FNDCNT=`grep "^${SRHPARM}$" /tmp/work_expand_dest_${PID} |wc -l`
	
#		echo "SRHLINE = ${SRHLINE} = return to continue" # 
#		read
		printf "\rProcessing rule %i" ${i}
		if (( $FNDCNT > 0 ))
		then
			# Update counts and flags, strip out from dest
			export MATCHCNT=`expr ${MATCHCNT} \+ ${FNDCNT}`	
			echo "MATCH:SRC:${i}:${SRHLINE}" >> /tmp/work_expand_results_${PID}
			grep "^${SRHPARM}$" /tmp/work_expand_dest_${PID} |awk -vitem=${i} '{print "MATCH:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
			grep -v "^${SRHPARM}$" /tmp/work_expand_dest_work_${PID} > /tmp/work_expand_dest_work_${PID}_2
			cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
			continue
		fi

		# Find conditions that are empty (match PASSWD:EXEC) or just have PASSWD or EXEC (Loop around) 
		# Do this separate from the check as we use the FILLINLIST later for match host
		export PARMLIST=`echo "${SRHPARM}" |awk -F":" '{print $4}'`
		if [[ "${PARMLIST}" == "" || "${PARMLIST}" == "PASSWD~" ||  "${PARMLIST}" == "NOPASSWD~" ]]
		then
			# Zero Parm or missing "EXEC"
			if [[ "${PARMLIST}" == "" ]]
			then
				export FILLINLIST="PASSWD~EXEC~"
			else
				export F1=`echo "${PARMLIST}" |awk -F"~" '{print $1}'`
				export F2=`echo "${PARMLIST}" |awk -F"~" '{print $1}'`

				# Check if both Empty
				if [[ "${F1}" == "" && "${F2}" == "" ]]
				then	
					export FILLINLIST="PASSWD~NOEXEC~"
				fi

				# If got PASSWD or NOPASSWD, add to FILLINLIST
				export PASSWDFLAG=0
				export EXECFLAG=0
				export FNDCNT=`echo "${F1}" |grep PASSWD |wc -l`
				if (( $FNDCNT > 0 ))
				then
					export FILLINLIST="${F1}~"
					export PASSWDFLAG=1
				fi
				export FNDCNT=`echo "${F2}" |grep PASSWD |wc -l`
				if (( $FNDCNT > 0 && $PASSWDFLAG < 1 ))
				then
					export FILLINLIST="${F2}~"
					export PASSWDFLAG=1
				fi
				if (( $PASSWDFLAG < 1 ))
				then
					# No flag, add it in
					export FULLINLIST="PASSWD~"
				fi	
	
				# If got EXEC or NOEXEC, add in 
				export FNDCNT=`echo "${F1}" |grep EXEC |wc -l`
				if (( $FNDCNT > 0 ))
				then
					export FILLINLIST="${FILLINLIST}${F1}~"
					export EXECFLAG=1
				fi
				export FNDCNT=`echo "${F2}" |grep EXEC |wc -l`
				if (( $FNDCNT > 0 && $EXECFLAG < 1 ))
				then
					export FILLINLIST="${FILLINLIST}${F2}~"
					export EXECFLAG=1
				fi
				if (( $EXECFLAG < 1 ))
				then
					# No flag, add it in
					export FILLINLIST="${FILLINLIST}EXEC~"
				fi	
	
			fi	
		else
			# Just use current value
			export FILLINLIST="${PARMLIST}"
		fi	

		# Do checks proper
		export DEFPARMSTART=`echo "${SRHPARM}" |awk -F":" '{print $1":"$2":"$3}'`
		export DEFPARMEND=`echo "${SRHPARM}" |awk -F":" '{for(i=5;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`

		export FNDCNT=`grep "^${DEFPARMSTART}:${FILLINLIST}:${DEFPARMEND}$" /tmp/work_expand_dest_${PID} |wc -l`
		if (( $FNDCNT > 0 ))
		then
			export DEFCONDCNT=`expr ${DEFCONDCNT} \+ ${FNDCNT}`
			echo "DEFAULTCOND:SRC:${i}:${SRHLINE}" >> /tmp/work_expand_results_${PID}
		
			grep "^${DEFPARMSTART}:${FILLINLIST}:${DEFPARMEND}$" /tmp/work_expand_dest_${PID} |awk -vitem=${i} '{print "DEFAULTCOND:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
			grep -v "^${DEFPARMSTART}:${FILLINLIST}:${DEFPARMEND}$" /tmp/work_expand_dest_work_${PID} >  /tmp/work_expand_dest_work_${PID}_2
			cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
			continue
		fi
		
		# Find all other non-conditions
		# export NONCONDPARM=`echo "${SRHPARM}" |awk -F":" '{print $1":"$2":"$3"::"$5}'`
		# export FNDCNT=`grep "^${NONCONDPARM}$" /tmp/work_expand_dest_${PID} |wc -l`
		# if (( $FNDCNT > 0 ))
		# then
		#	export NONCONDCNT=`expr ${NONCONDCNT} \+ ${FNDCNT}`
		#	echo "NONCOND:SRC:${i}:${SRHPARM}" >> /tmp/work_expand_results_${PID}
		#	grep "^${NONCONDPARM}$" /tmp/work_expand_dest_${PID} |awk -vitem=${i} '{print "NONCOND:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
		#	grep -v "^${NONCONDPARM}$" /tmp/work_expand_dest_work_${PID} > /tmp/work_expand_dest_work_${PID}_2
		#	cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
		#	continue
		# fi

		# Check for different CONDITION
		export DIFFCONDPARM=`echo "${SRHPARM}" |awk -F":" '{print $1":"$2":"$3}'`
		# export DIFFCONDSUFFIX=`echo "${SRHPARM}" |awk -F":" '{print $5}'`
		export DIFFCONDSUFFIX=`echo "${SRHPARM}" |awk -F":" '{for(i=5;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`
		export FNDCNT=`grep "^${DIFFCONDPARM}:" /tmp/work_expand_dest_${PID} |grep ":${DIFFCONDSUFFIX}$" |wc -l`
		if (( $FNDCNT > 0 ))
		then
			export DIFFCONDCNT=`expr ${DIFFCONDCNT} \+ ${FNDCNT}`
			echo "DIFFCOND:SRC:${i}:${SRHLINE}" >> /tmp/work_expand_results_${PID}
			grep "^${DIFFCONDPARM}:" /tmp/work_expand_dest_${PID} |grep ":${DIFFCONDSUFFIX}$" |awk -vitem=${i} '{print "DIFFCOND:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
			grep -v "^${DIFFCONDPARM}:"  /tmp/work_expand_dest_work_${PID} >  /tmp/work_expand_dest_work_${PID}_2
			grep "^${DIFFCONDPARM}:"  /tmp/work_expand_dest_work_${PID} |grep -v ":${DIFFCONDSUFFIX}$" >> /tmp/work_expand_dest_work_${PID}_2
			cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
			continue
		fi

		# Check for match host ALL or hostname (both the same) and the same or equivalent condition  (next test check match host, ignores condition)
		export HOSTSPEC=`echo "${SRHPARM}" |awk -F":" '{print $2}'`
		if [[ "${HOSTSPEC}" == "ALL" ]]
		then
			# export MATCHHOSTPARM=`echo "${SRHPARM}" |awk -F":" -vsrchost=${SRCHOST} '{print $1":"srchost":"$3}'`
			# export MATCHHOSTSUFFIX=`echo "${SRHPARM}" |awk -F":" '{print $5}'`
			export MATCHHOSTPREF=`echo "${SRHPARM}" |awk -F":" -vsrchost=${SRCHOST} -vfillin=${FILLINLIST} '{print $1":"srchost":"$3":"fillin}'`
			export MATCHHOSTSUFFIX=`echo "${SRHPARM}" |awk -F":" '{for(i=5;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`
		else
			# export MATCHHOSTPARM=`echo "${SRHPARM}" |awk -F":" -vsrchost=${SRCHOST} '{print $1":ALL:"$3}'`
			# export MATCHHOSTSUFFIX=`echo "${SRHPARM}" |awk -F":" '{print $5}'`
			export MATCHHOSTPREF=`echo "${SRHPARM}" |awk -F":" -vsrchost=${SRCHOST} -vfillin=${FILLINLIST} '{print $1":ALL:"$3":"fillin}'`
			export MATCHHOSTSUFFIX=`echo "${SRHPARM}" |awk -F":" '{for(i=5;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`
		fi
		export MATCHHOSTPARM="${MATCHHOSTPREF}:${MATCHHOSTSUFFIX}"
		export FNDCNT=`grep "^${MATCHHOSTPARM}$" /tmp/work_expand_dest_${PID} |wc -l`
		if (( $FNDCNT > 0 ))
		then
			export MATCHHOSTCNT=`expr ${MATCHHOSTCNT} \+ 1`
			echo "MATCHHOST:SRC:${i}:${SRHLINE}" >> /tmp/work_expand_results_${PID}
			# temp comment grep "^${MATCHHOSTPARM}:" /tmp/work_expand_dest_${PID} |grep ":${MATCHHOSTSUFFIX}$" |awk -vitem=${i} '{print "MATCHHOST:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
			# temp comment grep -v "^${MATCHHOSTPARM}:" /tmp/work_expand_dest_${PID}  > /tmp/work_expand_dest_work_${PID}_2
			# temp comment grep "^${MATCHHOSTPARM}:" /tmp/work_expand_dest_${PID} |grep -v ":${MATCHHOSTSUFFIX}$" >> /tmp/work_expand_dest_work_${PID}_2
			# temp comment cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
			grep "^${MATCHHOSTPARM}$" /tmp/work_expand_dest_${PID} |awk -vitem=${i} '{print "MATCHHOST:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
			grep -v "^${MATCHHOSTPARM}$" /tmp/work_expand_dest_${PID}  > /tmp/work_expand_dest_work_${PID}_2
			cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
			continue
		fi

		# Check for match host ALL or hostname (both the same) AND ignore conditions
                if [[ "${HOSTSPEC}" == "ALL" ]]
                then
                        export MATCHHOSTPARM=`echo "${SRHPARM}" |awk -F":" -vsrchost=${SRCHOST} '{print $1":"srchost":"$3}'`
                        export MATCHHOSTSUFFIX=`echo "${SRHPARM}" |awk -F":" '{for(i=5;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`
                else
                        export MATCHHOSTPARM=`echo "${SRHPARM}" |awk -F":" -vsrchost=${SRCHOST} '{print $1":ALL:"$3}'`
                        export MATCHHOSTSUFFIX=`echo "${SRHPARM}" |awk -F":" '{for(i=5;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`
                fi
                export FNDCNT=`grep "^${MATCHHOSTPARM}:" /tmp/work_expand_dest_${PID} |grep ":${MATCHHOSTSUFFIX}$" |wc -l`
                if (( $FNDCNT > 0 ))
                then
                        export MATCHHOSTCONDCNT=`expr ${MATCHHOSTCONDCNT} \+ 1`
                        echo "MATCHHOSTCOND:SRC:${i}:${SRHLINE}" >> /tmp/work_expand_results_${PID}
                        grep "^${MATCHHOSTPARM}:" /tmp/work_expand_dest_${PID} |grep ":${MATCHHOSTSUFFIX}$" |awk -vitem=${i} '{print "MATCHHOSTCOND:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
                        grep -v "^${MATCHHOSTPARM}:" /tmp/work_expand_dest_${PID}  > /tmp/work_expand_dest_work_${PID}_2
                        grep "^${MATCHHOSTPARM}:" /tmp/work_expand_dest_${PID} |grep -v ":${MATCHHOSTSUFFIX}$" >> /tmp/work_expand_dest_work_${PID}_2
                        cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
                        continue
                fi

		# Check for missing user only (and ignore conditions) 
		export MISSUSERPARM=`echo "${SRHPARM}" |awk -F":" '{print $2":"$3}'`
		export MISSUSERSUFFIX=`echo "${SRHPARM}" |awk -F":" '{for(i=5;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`
		export FNDCNT=`grep "^${MISSUSERPARM}:" /tmp/work_expand_dest_${PID} |grep ":${MISSUSERSUFFIX}$" |wc -l`
		if (( $FNDCNT > 0 ))
		then	
			export MISSUSERCNT=`expr ${MISSUSERCNT} \+ ${FNDCNT}`
			echo "MISSUSER:SRC:${i}:${SRHLINE}" >> /tmp/work_expand_results_${PID}
			grep ":${MISSUSERPARM}:" /tmp/work_expand_dest_${PID} |grep ":${MISSUSERSUFFIX}$" |awk -vitem=${i} '{print "MISSUSER:DEST:"item":"$0}' >> /tmp/work_expand_results_${PID}
			grep -v ":${MISSUSERPARM}:" /tmp/work_expand_dest_work_${PID} > /tmp/work_expand_dest_work_${PID}_2
			grep ":${MISSUSERPARM}:" /tmp/work_expand_dest_work_${PID} |grep -v ":${MISSUSERSUFFIX}$" >> /tmp/work_expand_dest_work_${PID}_2
			cp /tmp/work_expand_dest_work_${PID}_2 /tmp/work_expand_dest_work_${PID}
			continue
		fi

		# 
		# Now at end, add $i to unallocatyede list
		export UNALLOCLIST="${UNALLOCLIST} ${i} "
	done	

	export FOUNDCNT=`expr ${MATCHCNT} \+ ${DEFCONDCNT} \+ ${DIFFCONDCNT} \+ ${MISSUSERCNT} \+ ${MATCHHOSTCNT}`

	# Output those left
 	for i in $(echo "${UNALLOCLIST}")
 	do
 		# 
 		# grep -i "^${TGTENTRY}:SRC:${i}:" /tmp/work_expand_results_${PID} |awk -F":" '{printf(" - %3i:%-5s :%-20s:%-20s:%-20s:%-20s:%s\n", $3, $2, $4, $5, $6, $7, $8)}'
		grep -i "^${i}:" /tmp/work_expand_source_work_${PID} |head -n 1 |awk '{print "NOMATCH:SRC:"$0}' >> /tmp/work_expand_results_${PID}
	done
	export LEFTCNT=`echo "${UNALLOCLIST}" |awk '{print NF}'`

	# COmment this out, done by selection now	
	printf "\n"
#	echo "+ Complete match is ${MATCHCNT} entries"
# 	export TGTENTRY="MATCH"
# 	format_output
# 	echo
# 	echo "+ Empty or default condition is ${DEFCONDCNT} entries"
# 	export TGTENTRY="DEFAULTCOND"
# 	format_output
# 	echo
# 	echo "+ Match Host and condition is ${MATCHHOSTCNT} entries"
# 	export TGTENTRY="MATCHHOST"
# 	format_output
# 	echo
# 	echo "+ Match Host and different condition is ${MATCHHOSTCONDCNT} entries"
# 	export TGTENTRY="MATCHHOSTCOND"
# 	format_output
# 	echo
# 	echo "+ Different condition is ${DIFFCONDCNT} items"
# 	export TGTENTRY="DIFFCOND"
# 	format_output
# 	echo
# 	echo "+ User mismatch condition is ${MISSUSERCNT}"
# 	export TGTENTRY="MISSUSER"
#	format_output
#	echo
#	echo "    Total: ${TOTCNT} FOudncont ${FOUNDCNT}"
#	echo "	  Rest of = ${LEFTCNT} unalloclist: ${UNALLOCLIST}"
#	echo
#         echo "  Seq |      |Userid              | Host               | User               | Conditional        | Command "
#         echo "======+======+====================+====================+====================+====================+================="
# 	for i in $(echo "${UNALLOCLIST}")
# 	do
# 		# 
# 		# grep -i "^${TGTENTRY}:SRC:${i}:" /tmp/work_expand_results_${PID} |awk -F":" '{printf(" - %3i:%-5s :%-20s:%-20s:%-20s:%-20s:%s\n", $3, $2, $4, $5, $6, $7, $8)}'
#		grep -i "^${i}:" /tmp/work_expand_source_work_${PID} |head -n 1 |awk -F":" '{printf(" - %3i:      :%-20s:%-20s:%-20s:%-20s:%s\n", $1, $2, $3, $4, $5, $6, $7, $8)}'
#	done	
#	echo
#	export REMCNT=`cat /tmp/work_expand_dest_work_${PID} |wc -l`
#	echo "    Unallocated /tmp/work_expand_dest_work_${PID} - ${REMCNT} left"
#	echo "    Master List /tmp/work_expand_source_work_${PID}"

	# Update hostory file
	export DTG=`date '+%Y%m%d-%H%M%S'`
	echo "${DTG}:${SRCHOST}:${MATCHCNT}:${DEFCONDCNT}:${MATCHHOSTCNT}:${MATCHHOSTCONDCNT}:${DIFFCONDCNT}:${MISSUSERCNT}:${LEFTCNT}" >> $HISTFILE
	echo "Return to continue"
	read
}

function compare_menu
{
	# split out and compare 
	export OPTION=""
	while [[ "${OPTION}" != [Qq] ]]
	do
		clear
		echo "             Compare files sudoers"
		echo "            ======================="
		echo

		export SRCCNT=`cat /tmp/work_expand_source_${PID} |wc -l`
		export DESTCNT=`cat /tmp/work_expand_dest_${PID} |wc -l`
		# echo "  SRC: /tmp/work_expand_source_${PID} $(SRCCNT} Lines"
		# echo " DEST: /tmp/work_expand_dest_${PID} $(DESTCNT} Lines"
		# Note: do not use echo for SRC and DEST, it can't handle something and I can't figure out what
		# Note: use printf instead
		printf "  SRC: %-30s - %i lines\n" "/tmp/work_expand_source_${PID}" ${SRCCNT}
		printf " DEST: %-30s - %i lines\n" "/tmp/work_expand_dest_${PID}" ${DESTCNT}
		echo

		# Do matchup - exact lines
		compare_files
	
		echo "Enter options"
		read	
	done

	echo
}

function expand_out_rules
{
	# Check we have a alias expand
	if [[ ! -f /tmp/work_expanded_all_alias_${PID} ]]
	then
		echo "Alias /tmp/work_expanded_all_alias_${PID} not expanded out, these are pre-reqs for rules - exiting"
		exit
	fi

	# Strip out lines (and cater for continuation) - do not use asterisk rule for now
	##### cat ${SRCFILE} | awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g' > /tmp/work_line_cont_fix_${PID}
	#### grep -v "^Host_Alias" /tmp/work_line_cont_fix_${PID} |grep -v "^Cmnd_Alias" |grep -v "User_Alias" |grep -v "^Defaults" |awk 'NF > 0 {print $0}' |awk '{for(i=1;i<=NF;i++) printf("%s ", $i)}{printf("\n")}' |sed 's/ $//g' |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' | sed 's/\*/\\\*/g' > /tmp/work_expanded_rules_${PID}
	grep -v "^Host_Alias" /tmp/work_line_cont_fix_${PID} |grep -v "^Cmnd_Alias" |grep -v "User_Alias" |grep -v "^Defaults" |awk 'NF > 0 {print $0}' |awk '{for(i=1;i<=NF;i++) printf("%s ", $i)}{printf("\n")}' |sed 's/ $//g' |sed 's/^ //g' |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_expanded_rules_${PID}

	# Loop through rules and strip out commas
	cat /dev/null > /tmp/work_expand_rules_strip_${PID}
	for i in $(cat /tmp/work_expanded_rules_${PID} |awk -F":" '{print $1}' |sort -u)
	do
		# Strip out line and decode
		# ASTERIX FIX - export SRCLINE=`grep "^${i}:" /tmp/work_expanded_rules_${PID} |head -n 1 |sed "s/^${i}://g" |sed 's/\*/\\\*/g'`
		export SRCLINE=`grep "^${i}:" /tmp/work_expanded_rules_${PID} |head -n 1 |sed "s/^${i}://g"`
		export PT1=`echo "${SRCLINE}" |awk -F"=" '{print $1}'`
		export PT2=`echo "${SRCLINE}" |awk -F"=" '{for(i=2;i<=NF;i++) {printf("%s=", $i)}}' |sed 's/=$//g' |sed 's/^ //g'`
		# export NUMF=`echo "${SRCLINE}" |awk -F"=" '{print NF}'`
		# if (( $NUMF == 2 )) 
		# then
	 	#	export PT2=`echo "${SRCLINE}" |awk -F"=" '{print $2}'`
		# elif (( $NUMF == 3 ))
		# then
		#	export PT2=`echo "${SRCLINE}" |awk -F"=" '{print $2"="$3}'`
		# elif (( $NUMF == 4 ))	
		# then
		#	export PT2=`echo "${SRCLINE}" |awk -F"=" '{print $2"="$3"="$4}'`
		# elif (( $NUMF == 0 ))	
		# then
		#	echo "improperly formatted sudoers line ${SRCLINE} i = ${i} - NO equals signs" >> /tmp/work_sudoers_errfile_${PID}
		# else
		#	echo "improperly formatted sudoers line ${SRCLINE} i = ${i} - more than 3 equals signs" >> /tmp/work_sudoers_errfile_${PID}
		#	continue
		# fi
		
		# Split out users and hosts
		export TGTUSERS=`echo "${PT1}" |awk '{print $1}'`
		export TGTHOSTS=`echo "${PT1}" |awk '{print $2}'`
		export NUMF=`echo "${PT1}" |awk '{print NF}'`
		if (( $NUMF != 2 ))
		then
			echo "too many fields before = ${PT1}" >> /tmp/work_sudoers_errfile_${PID}
			continue
		fi

		# Strip out user defined
		export USERRULE="root"
		export RESTRULE="${PT2}"
		export USERDEF=`echo "${PT2}" |awk '{print substr($1, 1, 1)}'`
		if [[ "${USERDEF}" == "(" ]]
 		then
			export USERRULE=`echo "${PT2}" |sed 's/)/ /g' |sed 's/(/ /g' |awk '{print $1}'`
			export RESTRULE=`echo "${PT2}" |sed 's/)/ /g' |sed 's/(/ /g' |awk '{for(i=2;i<=NF;i++) printf("%s ", $i)} {printf("\n")}' |sed 's/ $//g'`
		fi

		# Strip out PASSWD and EXEC conditions (Change to use context - space delimited conditions - look for passwd or exec)
		export POSSIBLECOND==`echo "${RESTRULE}" |awk '{print $1}'`
		export COLCNT=`echo "${POSSIBLECOND}" |grep -E "PASSWD|EXEC" |grep ":" |wc -l`
		export CMDRULE=""
		if (( $COLCNT > 0 ))
		then
			# Strip out conditions	
			export COND=`echo "${RESTRULE}" |awk '{print $1}' |awk -F":" '{for(i=1;i<NF;i++) printf("%s~", $i)}'`
			export CMDRULE=`echo "${RESTRULE}" |awk '{for(i=2;i<=NF;i++) printf("%s ", $i)}' |sed 's/ $//g'`
		else
			export COND=""
			export CMDRULE=`echo ${RESTRULE} |sed 's/^ //g'`
		fi
	
		# Strip out command rule
		echo "${CMDRULE}" |awk -F"," '{for(i=1;i<=NF;i++) printf("%s\n", $i)}' |sed 's/^ //g' > /tmp/work_expanded_onlyrules_${PID}

		# Loop through and generate full file - users, hosts, commands
		for j in $(echo "${TGTUSERS}" |sed 's/,/ /g')
		do
			for k in $(echo "${TGTHOSTS}" |sed 's/,/ /g')
			do
				# Cat the users, hosts and commands
				cat /tmp/work_expanded_onlyrules_${PID} |awk -vusers=${j} -vhosts=${k} -vurule=${USERRULE} -vcond=${COND} '{print users":"hosts":"urule":"cond":"$0}' >> /tmp/work_expand_rules_strip_${PID}
			done
		done
		echo "${SRCLINE} - breakdown"
		echo "Target users :${TGTUSERS}:"
		echo "Target hosts :${TGTHOSTS}:"
		echo "User rule :${USERRULE}:"
		echo "Condition :${COND}:"
		echo "Command rule :${CMDRULE}:"
		echo "--------------"
	done

	# Now loop through and gather host aliases
	cat /tmp/work_expand_rules_strip_${PID} |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_expand_rules_work_${PID}
	
	echo "First expand completed"
	# ls -al /tmp/work_expand_rules_strip_${PID} 
	# cat /tmp/work_expand_rules_strip_${PID}

	cat /dev/null > /tmp/work_expand_rules_temp_${PID}
	for i in $(cat /tmp/work_expand_rules_work_${PID} |awk -F":" '{print $1}' |sort -u)
	do
		# Read in line 
		export LINE1=`grep "^${i}:" /tmp/work_expand_rules_work_${PID} |head -n 1`
		export SRHUSER=`echo "${LINE1}" |awk -F":" '{print $2}'`
		export REMAINDER=`echo "${LINE1}" |awk -F":" '{for(i=3;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`

		# Find occurences of User alias in /tmp/work_expanded_all_alias_${PID}
		export FNDCNT=`grep "^User_Alias:${SRHUSER}:" /tmp/work_expanded_all_alias_${PID} |wc -l`
		if (( $FNDCNT < 1 ))
		then
			# No user swaps, just add line to outfile
			echo "${SRHUSER}:${REMAINDER}" >> /tmp/work_expand_rules_temp_${PID}
		else
			# add all entries for user to outfile
			grep "^User_Alias:${SRHUSER}:" /tmp/work_expanded_all_alias_${PID} |awk -F":" -vremain="${REMAINDER}" '{print $3":"remain}' >> /tmp/work_expand_rules_temp_${PID}
		fi

	done

	# Now copy back and start on host alias
	cat /tmp/work_expand_rules_temp_${PID} |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_expand_rules_work_${PID}
	cat /dev/null > /tmp/work_expand_rules_temp_${PID}
	for i in $(cat /tmp/work_expand_rules_work_${PID} |awk -F":" '{print $1}' |sort -u)
	do
		# Read in line
		export LINE1=`grep "^${i}:" /tmp/work_expand_rules_work_${PID} |head -n 1`
		export ORIGUSER=`echo "${LINE1}" |awk -F":" '{print $2}'`
		export SRHHOST=`echo "${LINE1}" |awk -F":" '{print $3}'`
		export REMAINDER=`echo "${LINE1}" |awk -F":" '{for(i=4;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`

		# Find occurences of User alias in /tmp/work_expanded_all_alias_${PID}
		export FNDCNT=`grep "^Host_Alias:${SRHHOST}:" /tmp/work_expanded_all_alias_${PID} |wc -l`
		if (( $FNDCNT < 1 ))
		then
			# No user swaps, just add line to outfile
			echo "${ORIGUSER}:${SRHHOST}:${REMAINDER}" >> /tmp/work_expand_rules_temp_${PID}
		else
			# add all entries for user to outfile
			grep "^Host_Alias:${SRHHOST}:" /tmp/work_expanded_all_alias_${PID} |awk -F":" -vsrhuser="${ORIGUSER}" -vremain="${REMAINDER}" '{print srhuser":"$3":"remain}' >> /tmp/work_expand_rules_temp_${PID}

		fi
	done

	# Now copy back and start on command alias
	cat /tmp/work_expand_rules_temp_${PID} |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_expand_rules_work_${PID}
	cat /dev/null > /tmp/work_expand_rules_temp_${PID}

	for i in $(cat /tmp/work_expand_rules_work_${PID} |awk -F":" '{print $1}' |sort -u)
	do
		# Read in line
		export LINE1=`grep "^${i}:" /tmp/work_expand_rules_work_${PID} |head -n 1`
		export ORIGUSERHOST=`echo "${LINE1}" |awk -F":" '{print $2":"$3":"$4":"$5}'`
		# export ORIGCOMMAND=`echo "${LINE1}" |awk -F":" '{print $6}'`
		export ORIGCOMMAND=`echo "${LINE1}" |awk -F":" '{for(i=6;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`
		# export SRHCOMMAND=`echo "${LINE1}" |sed 's/\*/\\\*/g' | sed 's/\[/\\\[/g' |awk -F":" '{print $6}'`
		export SRHCOMMAND=`echo "${LINE1}" |sed 's/\*/\\\*/g' | sed 's/\[/\\\[/g' |awk -F":" '{for(i=6;i<=NF;i++) printf("%s:", $i)}' |sed 's/:$//g'`

		# Skip if more than 1 word, as will be literal command
		export WCNT=`echo "${SRHCOMMAND}" |awk '{print NF}'`
		if (( $WCNT > 1 ))
		then
			echo "${ORIGUSERHOST}:${ORIGCOMMAND}" >> /tmp/work_expand_rules_temp_${PID}
			continue
		fi
		# Find occurences of User alias in /tmp/work_expanded_all_alias_${PID}
		export FNDCNT=`grep "^Cmnd_Alias:${SRHCOMMAND}:" /tmp/work_expanded_all_alias_${PID} |wc -l`
		if (( $FNDCNT < 1 ))
		then
			# No user swaps, just add line to outfile
			echo "${ORIGUSERHOST}:${ORIGCOMMAND}" >> /tmp/work_expand_rules_temp_${PID}
		else
			# add all entries for user to outfile AAAA
			# export OUTCOMMAND=`grep "^Cmnd_Alias:${SRHCOMMAND}:" /tmp/work_expanded_all_alias_${PID} |awk -F":" '{for(i=3;i<=NF;i++) {printf("%s:", $i)}}' |sed 's/:$//g'`
			# echo "${ORIGUSERHOST}:${OUTCOMMAND}" >> /tmp/work_expand_rules_temp_${PID}
			grep "^Cmnd_Alias:${SRHCOMMAND}:" /tmp/work_expanded_all_alias_${PID} |awk -F":" -vsrhuser="${ORIGUSERHOST}" '{printf("%s:", srhuser)}{for(i=3;i<=NF;i++) {printf("%s:", $i)}}{printf("\n")}' |sed 's/:$//g' >> /tmp/work_expand_rules_temp_${PID}
		fi
	done
	
	echo "Final expand completed"
	ls -al /tmp/work_expand_rules_temp_${PID}
}

function expand_out_alias
{

# Strip out Host Alias - wrap file around for line continuation (put work around for asterisks in each line parameter)
grep "^${TGTALIAS}" /tmp/work_line_cont_fix_${PID} |sed "s/${TGTALIAS}//g" |awk '{for(i=1;i<=NF;i++) printf("%s ", $i)}{printf("\n")}' |sed 's/ $//g' >  /tmp/work_alias_${PID}

# Strip out allowing more than 1 equals (=) sign

# Loop around and strip out lines specifically, so we can identify more than one equals sign and split commands out accordingly
cat /tmp/work_alias_${PID} |awk 'BEGIN {ind=0} {ind=ind+1;print ind":"$0}' > /tmp/work_alias_seq_${PID}
cat /dev/null > /tmp/work_host_alias_${PID}
for i in $(cat /tmp/work_alias_seq_${PID} |awk -F":" '{print $1}' |sort -u)
do
	export LINE1=`grep "^${i}:" /tmp/work_alias_seq_${PID} |head -n 1 |sed "s/^${i}://g"`
	export ANAME=`echo "${LINE1}" |awk -F"=" '{print $1}' |sed 's/ //g'`
	export ALIST=`echo "${LINE1}" |awk -F"=" '{for(i=2;i<=NF;i++) printf("%s=", $i)}' |sed 's/=$//g' |sed 's/^ //g'`

	# Now strip out commas from ALIST and add to file then add to ANAME
	echo "${ALIST}" |awk -F"," '{for(i=1;i<=NF;i++) printf("%s\n", $i)}' |sed 's/^ //g' > /tmp/work_host_alias_multi_${PID}
	cat /tmp/work_host_alias_multi_${PID} |awk -vaname=${ANAME} '{print aname":"$0}' >> /tmp/work_host_alias_${PID}
done

# OLD CODE
# cat /tmp/work_alias_${PID} |sed 's/=/,/g' |awk -F"=" '{name=$1}{for(i=2;i<=NF;i++) printf("%s:%s\n", name, $i)}' |sed 's/^ //g' |sed 's/: /:/g'  |sed 's/ :/:/g' > /tmp/work_host_alias_${PID}

#  REMOVED |sed 's/\*/\\\\\*/g'
# Strip out lines with more than 1 column, these are commands and do not need to be tracked
cat /tmp/work_host_alias_${PID} |awk 'NF > 1 {print $0}' > /tmp/work_host_alias_save_${PID}
cat /tmp/work_host_alias_${PID} |awk 'NF == 1 {print $0}' > /tmp/work_host_alias_trim_${PID} 
cp /tmp/work_host_alias_trim_${PID} /tmp/work_host_alias_new_${PID}

# Loop around
# export NEWLNCOUNT=0
# export LNCOUNT=`cat /tmp/work_host_alias_trim_${PID} |wc -l`
export LNCOUNT=0
export NEWLNCOUNT=`cat /tmp/work_host_alias_trim_${PID} |wc -l`
export SEQLOOP=0
while (( $LNCOUNT < $NEWLNCOUNT ))
do
	# Create work file and 
	cp /tmp/work_host_alias_new_${PID} /tmp/work_host_alias_trim_${PID}

	cat /dev/null > /tmp/work_host_alias_new_${PID}
	cp /tmp/work_host_alias_trim_${PID} /tmp/work_host_alias_work_${PID}
	export LNCOUNT=`cat /tmp/work_host_alias_trim_${PID} |wc -l`
	export WORKLNCOUNT=`cat /tmp/work_host_alias_work_${PID} |wc -l`
	while (( $WORKLNCOUNT > 0 ))
	do
		# Find occurences
		export LINE1=`head -n 1 /tmp/work_host_alias_work_${PID}`
		export SRHLINE1=`echo "${LINE1}" |sed 's/\*/\\\\\*/g' |sed 's/\!/\\\\\!/g' |sed 's/\[/\\\[/g'`
		export SRCGROUP=`echo "${LINE1}" |awk -F":" '{print $1}'`
		export TGTGROUP=`echo "${LINE1}" |awk -F":" '{print $2}'`
		export USECNT1=`grep "^${TGTGROUP}:" /tmp/work_host_alias_trim_${PID} |wc -l`
		export USECNT2=`grep "^${TGTGROUP}:" /tmp/work_host_alias_save_${PID} |wc -l`
		if (( $USECNT1 > 0 ))
		then
			# add in replacement entries
			grep -i "^${TGTGROUP}:" /tmp/work_host_alias_trim_${PID} |awk -vsrc=${SRCGROUP} -F":" '{print src":"$2}' >> /tmp/work_host_alias_new_${PID}
		elif (( $USECNT2 > 0 ))
		then
			grep -i "^${TGTGROUP}:" /tmp/work_host_alias_save_${PID} |awk -vsrc=${SRCGROUP} -F":" '{print src":"$2}' >> /tmp/work_host_alias_new_${PID}
		else
			echo "${LINE1}" >> /tmp/work_host_alias_new_${PID}
		fi

		grep -v "^${SRHLINE1}$" /tmp/work_host_alias_work_${PID} > /tmp/work_host_alias_work_${PID}_2
		cp /tmp/work_host_alias_work_${PID}_2 /tmp/work_host_alias_work_${PID}
		export WORKLNCOUNT=`cat /tmp/work_host_alias_work_${PID} |wc -l`

	done < /tmp/work_host_alias_work_${PID}
	printf "\n"
	# Confirm before and after
	export NEWLNCOUNT=`cat /tmp/work_host_alias_new_${PID} |wc -l`
	echo "TGTALIAS ${TGTALIAS} Before LNCOUNT ${LNCOUNT} After LNCOUNT ${NEWLNCOUNT} - return to continue"
 	# ls -al /tmp/work_host_alias_trim_${PID} /tmp/work_host_alias_new_${PID}
	# read		
done

# Append /tmp/work_host_alias_save_${PID}
echo "results - append saved entries"
cat /tmp/work_host_alias_save_${PID} >>  /tmp/work_host_alias_new_${PID}
cat /tmp/work_host_alias_new_${PID}
cat /tmp/work_host_alias_new_${PID} |awk -vsrc=${TGTALIAS} '{print src":"$0}' >> /tmp/work_expanded_all_alias_${PID}

}

function regen_extracts
{
# update figures for checksum - convert to use multiple filenames
cat /dev/null > /tmp/work_sudoers_errfile_${PID}
cat /dev/null > /tmp/work_expanded_all_alias_${PID}
cat /dev/null > /tmp/work_line_cont_fix_${PID}
for WORKFILE in $(echo "${ORIGFILE}")
do
	export ORIGSUM=`sum ${WORKFILE} |awk '{print $1"_"$2}'`
	grep -v "^ORIGSUM:${WORKFILE}" ${CFGFILE} > ${CFGFILE}_2
	echo "ORIGSUM:${WORKFILE}:${ORIGSUM}" >> ${CFGFILE}_2
	cp ${CFGFILE}_2 ${CFGFILE}
	### REMOVE ASTERISK REPLASCEMTN cat ${WORKFILE} | awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g' >> /tmp/work_line_cont_fix_${PID}
	cat ${WORKFILE} | awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g'  >> /tmp/work_line_cont_fix_${PID}
done

export TGTALIAS="Host_Alias"
expand_out_alias
export TGTALIAS="Cmnd_Alias"
expand_out_alias
export TGTALIAS="User_Alias"
expand_out_alias

# Now find rules and create rules list (cater for line wrap)
expand_out_rules

# Remove duplicate hosts with full and shortbames
printf "\n"

# Strip out hosts and look for short and long name
cat /tmp/work_expand_rules_temp_${PID} |awk -F":" '{print $2}' |grep -i police.govt.nz |sort -u > /tmp/work_expand_find_duplicates_${PID}
for i in $(cat /tmp/work_expand_find_duplicates_${PID})
do
	# Find if short occurenace
	export SHORTNAME=`echo "${i}" |sed 's/\./ /g' |awk '{print $1}'`
	export FNDCNT=`cat /tmp/work_expand_rules_temp_${PID} |awk -F":" '{print $2}' |grep "^${SHORTNAME}$" |wc -l`
	if (( $FNDCNT > 0 ))
	then
		# Strip out rules for both and work through
		cat /tmp/work_expand_rules_temp_${PID} |awk -vlongsrc=${i} -F":" '$2 == longsrc {print $0}' > /tmp/work_expand_rules_duplicate_host_${PID}
		export LNCOUNT=`cat /tmp/work_expand_rules_duplicate_host_${PID} |wc -l`
		while (( $LNCOUNT > 0 ))
		do
			# look for shortname 
			printf "\rScanning Host %s Line %i" ${i} ${LNCOUNT}
			export LINE1=`head -n 1 /tmp/work_expand_rules_duplicate_host_${PID}`
			export SRHPARM=`echo "${LINE1}" |sed 's/\*/\\\*/g' |sed 's/\[/\\\[/g'`
			export DUPLPARM=`echo "${LINE1}" |sed 's/\*/\\\*/g' |sed 's/\[/\\\[/g' |awk -vshortname=${SHORTNAME} -F":" '{print $1":"shortname":"$3":"$4":"$5}'`
			# export SRHPARM=`echo "${LINE1}"`
			# export DUPLPARM=`echo "${LINE1}" |awk -vshortname=${SHORTNAME} -F":" '{print $1":"shortname":"$3":"$4":"$5}'`
			
			export DUPLCNT=`grep -i "^${DUPLPARM}$" /tmp/work_expand_rules_temp_${PID} |wc -l`
			if (( $DUPLCNT > 0 ))
			then
				# Remove from work expand rules
				grep -v "^${SRHPARM}$" /tmp/work_expand_rules_temp_${PID} > /tmp/work_expand_rules_temp_${PID}_2
				cp /tmp/work_expand_rules_temp_${PID}_2 /tmp/work_expand_rules_temp_${PID}

			fi
			
			grep -v "^${SRHPARM}$" /tmp/work_expand_rules_duplicate_host_${PID} > /tmp/work_expand_rules_duplicate_host_${PID}_2
			cp /tmp/work_expand_rules_duplicate_host_${PID}_2 /tmp/work_expand_rules_duplicate_host_${PID}	
			export LNCOUNT=`cat /tmp/work_expand_rules_duplicate_host_${PID} |wc -l`
		done
		
	fi
done

# Strip out rules for hostnames specific and the system groups and all
cat /tmp/work_expand_rules_temp_${PID} |awk -F":" -vsrchost=${SRCHOST} '$2 == "ALL" {print $0} substr($2, 1, 1) == "+" {print $0} $substr($2, 1, 1) == "%" {print $0} $2 == srchost {print $0}' > /tmp/work_expand_source_${PID}
cp /tmp/work_expanded_all_alias_${PID} /tmp/work_expanded_source_alias_${PID}

# Now do for second set of files
export NEWSUM=`sum ${NEWFILE} |awk '{print $1"_"$2}'`
grep -v "^NEWSUM:" ${CFGFILE} > ${CFGFILE}_2
echo "NEWSUM:${NEWSUM}" >> ${CFGFILE}_2
cp ${CFGFILE}_2 ${CFGFILE}

cat /dev/null > /tmp/work_expanded_all_alias_${PID}
##### REMOVE ASTERISK CODE FROM HERE
# cat ${NEWFILE} | awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g' > /tmp/work_line_cont_fix_${PID}
cat ${NEWFILE} | awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' > /tmp/work_line_cont_fix_${PID}

export TGTALIAS="Host_Alias"
expand_out_alias
export TGTALIAS="Cmnd_Alias"
expand_out_alias
export TGTALIAS="User_Alias"
expand_out_alias
 
# # Now find rules and create rules list (cater for line wrap)
expand_out_rules
 
cp /tmp/work_expand_rules_temp_${PID} /tmp/work_expand_dest_${PID}
cp /tmp/work_expanded_all_alias_${PID} /tmp/work_expanded_dest_alias_${PID}

# Update regen date
export REGDATE=`date`
grep -v "^LASTREGEN~" ${CFGFILE} > ${CFGFILE}_2
echo "LASTREGEN~${REGDATE}" >> ${CFGFILE}_2
cp ${CFGFILE}_2 ${CFGFILE}

# Checl errors and output
export ERRCNT=`cat /tmp/work_sudoers_errfile_${PID} |wc -l`
if (( $ERRCNT > 0 ))
then
	echo "FOUNDS ERRORS - return to continue"
	cat /tmp/work_sudoers_errfile_${PID}
	read
fi

# Reset display indicators
export MATCHCNT=0
export DEFCONDCNT=0
export MATCHHOSTCNT=0
export MATCHHOSTCONDCNT=0
export DIFFCONDCNT=0
export MISSUSERCNT=0
export LEFTCNT=0

export MATCHSHOW=0
export DEFAULTSHOW=0
export EQUIVSHOW=0
export CONDHOSTSHOW=0
export CONDSHOW=0
export USERSHOW=0
export NONESHOW=0
# echo "ALL DONE"
# echo "========="
ls -al /tmp/work_expand_source_${PID} /tmp/work_expand_dest_${PID}
# compare_menu
# 
# # Now match up correct matches, those that only miss match on conditions, then different for equiv user, then host, then actual user, then command
# # (exclude previous rules as you go down)
}

# NEW MAIN GROUP
export PARM=$*
export HNAME=`hostname -s`
if [[ $HNAME == "rhel7dsms" ]]
then
	export CFGFILE=/home/fred/compare_sudoers.cfg
	export HISTFILE=/home/fred/history_file
else
	export CFGFILE=/home/idza59/DSMS/compare_sudoers.cfg
	export HISTFILE=/home/idza59/DSMS/history_file
fi
if [[ ! -f "${CFGFILE}" ]]
then
	touch $CFGFILE
fi

# Load up variables - counts and show indicators
export MATCHCNT=0
export DEFCONDCNT=0
export MATCHHOSTCNT=0
export MATCHHOSTCONDCNT=0
export DIFFCONDCNT=0
export MISSUSERCNT=0
export LEFTCNT=0

export MATCHSHOW=0
export DEFAULTSHOW=0
export EQUIVSHOW=0
export CONDHOSTSHOW=0
export CONDSHOW=0
export USERSHOW=0
export NONESHOW=0

export OPTION=""
while [[ "${OPTION}" != [QqXx] ]]
do
	# Main menu
	clear
	echo "              Compare Sudoers"
	echo "             ================="
	echo

	# print menu	
	export ORIGFILE=`grep "^ORIGFILE:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	export NEWFILE=`grep "^NEWFILE:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
#	export ORIGSUM=`grep "^ORIGSUM:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	export NEWSUM=`grep "^NEWSUM:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`
	export SRCHOST=`grep "^SRCHOST:" ${CFGFILE} |head -n 1 |awk -F":" '{print $2}'`

	# Change to generate file for source files
	cat /dev/null > /tmp/work_orig_file_${PID}
	printf "   Source Host: %s\n" "${SRCHOST}"
	for i in $(echo "${ORIGFILE}")
	do
		# Get old sum and current sum
		export FLAG=""
		export ORIGSUM=`grep "^ORIGSUM:${i}:" ${CFGFILE} |head -n 1 |awk -F":" '{print $3}'`
		if [[ "${ORIGSUM}" == "" ]]
		then
			export ORIGSUM="XXX"
		fi
		export CURRSUM=`sum ${i} |awk '{print $1"_"$2}'`
		if [[ "${CURRSUM}" != "${ORIGSUM}" ]]
		then
			export FLAG="****"
		fi
		printf "   Orig file: %-60s OrigSum: %-12s Currsum: %-12s  %-4s\n" "${i}" ${ORIGSUM} ${CURRSUM} "${FLAG}" >>  /tmp/work_orig_file_${PID}
	done

	# if [[ "${ORIGFILE}" != "" ]]
	#then
	#	export CURRORIGSUM=`sum ${ORIGFILE} |awk '{print $1"_"$2}'`
	#else
	#	export CURRORIGSUM="XXXX"
	#fi
	if [[ "${NEWFILE}" != "" ]]
	then
		export CURRNEWSUM=`sum ${NEWFILE} |awk '{print $1"_"$2}'`
		if [[ ${CURRNEWSUM} != ${NEWSUM} ]]
		then
			export SUMFLAG="*****"
		else
			export SUMFLAG=""
		fi
	else
		export CURRNEWSUM="XXXX"
		export SUMFLAG="NA"
	fi
	# printf "   Orig file: %-30s GenSum: %-12s   Current Sum %-12s\n" ${ORIGFILE} ${ORIGSUM} ${CURRORIGSUM}
	cat  /tmp/work_orig_file_${PID}
	printf "    New file: %-60s GenSum: %-12s   Current Sum %-12s  Status: %s\n" ${NEWFILE} ${NEWSUM} ${CURRNEWSUM} "${SUMFLAG}"

	# Output stats - last regen, last checksums (and change in checksum)
	export LASTREGEN=`grep "^LASTREGEN~"  ${CFGFILE} |head -n 1 |awk -F"~" '{print $2}'`
	echo   "   Last Regen: ${LASTREGEN}"
	echo   "Source file: /tmp/work_expand_source_${PID}	/tmp/work_expanded_source_alias_${PID}"
	echo   "Dest file: /tmp/work_expand_dest_${PID}		/tmp/work_expanded_dest_alias_${PID}"
	echo

	# Output options
	echo "     R. Regen extracts"
	echo "     D. Analysis Defaults"
	echo "     A. Analysis Rules"
	echo "     C. Cat File"

	# Output Conditional values
	echo
	output_conditional_format

	echo "      F. Enter Filenames"
	echo

	echo

	printf "    Enter option:"
	read OPTION

	case "${OPTION}" in
	[Ff]) enter_filenames ;;
	[Rr]) regen_extracts ;;
	[Aa]) analysis_extracts ;;
	[Dd]) analysis_defaults ;;
	[Cc]) cat_file ;;
	[Ss]) search_file ;;
	[Hh]) show_history ;;
	[1-7]) analyse_format ;;
	*) ;;
	esac
done

#!/bin/bash

if [[ -f dsms_190h.tar.gz ]]
then
	rm -f dsms_190h.tar.gz
fi

tar -cvzf dsms_190h.tar.gz -T filelist

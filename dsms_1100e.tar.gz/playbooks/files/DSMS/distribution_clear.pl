#!/usr/bin/perl
 
# AMENDED, use sudoer_build location, and then detect if cutdown and serve up custom host if so
use strict;
 
use DBI;
use POSIX qw(strftime);
use Net::SFTP::Foreign;
 
require 'common.pl';
 
my $Date = strftime "%Y-%m-%d", localtime;
my $DB_Management = DB_Management();
my $DB_Sudoers = DB_Sudoers();
my $MD5Sum = md5sum();
my $Cut = cut();
# NO LONGER NEDEDmy $Sudoers_Location = Sudoers_Location();
my $Sudoers_Build = Sudoers_Build();
my $Sudoers_Location = "$Sudoers_Build/sudoers"; # NOT VALID, DEPENDS ON CUTDOWN OR NOT
 
my $MD5_Checksum = `$MD5Sum $Sudoers_Location | $Cut -d ' ' -f 1`;
 
# Safety check for other running distribution processes
 
my $Select_Locks = $DB_Management->prepare("SELECT `sudoers-build`, `sudoers-distribution` FROM `lock`");
$Select_Locks->execute();
 
my ($Sudoers_Build_Lock, $Sudoers_Distribution_Lock) = $Select_Locks->fetchrow_array();
{
        $DB_Management->do("UPDATE `lock` SET
                `sudoers-distribution` = '0',
                `last-distribution-started` = NOW()");
}

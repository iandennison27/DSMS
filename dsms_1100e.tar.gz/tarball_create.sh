#!/bin/bash

if [[ -f dsms_1100d.tar.gz ]]
then
	rm -f dsms_1100d.tar.gz
fi

tar -cvzf dsms_1100d.tar.gz -T filelist

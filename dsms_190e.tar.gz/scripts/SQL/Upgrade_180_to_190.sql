alter table host_groups add column `system_group` int(1) NOT NULL DEFAULT '0' AFTER `groupname`;

Use 'Management';
FLUSH PRIVILEGES;
CREATE USER 'Management'@'localhost' IDENTIFIED BY 'H7TG5;9CR}y;dV~i__K0Sw&@LogVv=+7';
GRANT SELECT,INSERT ON Management.access_log TO 'Management'@'localhost';
GRANT SELECT,INSERT ON Management.audit_log TO 'Management'@'localhost';
GRANT SELECT,INSERT,UPDATE,DELETE ON Management.credentials TO 'Management'@'localhost';
GRANT SELECT,INSERT,UPDATE,DELETE ON Management.distribution TO 'Management'@'localhost';
GRANT SELECT,UPDATE ON Management.lock TO 'Management'@'localhost';

Use 'Sudoers';
CREATE USER 'Sudoers'@'localhost' IDENTIFIED BY '0LwjQIjBB>A~Q3,]S-l0_rM:0Ct/*+sH';
GRANT SELECT,INSERT,UPDATE,DELETE ON Sudoers.* TO 'Sudoers'@'localhost';

FLUSH PRIVILEGES;

#!/bin/bash

# cat out and strip - clean first
cd /home/fred/dsms_data
for i in $(ls -A)
do
	if [[ -d ${i} ]]
	then
		echo "Deleting ${i}"
		rm -rf ${i}
	fi
done

# Get directory and filename
for i in $(grep "^Directory " data_out.txt |awk '{print $2}' |sort -u)
do
	mkdir /home/fred/dsms_data/${i}
	mkdir /home/fred/dsms_data/${i}/sudoers.d
	
	# Find files and strip out
	for j in $(grep "^Directory ${i} " data_out.txt |awk '{print $4}' |sort -u)
	do
		if [[ ${j} == "sudoers" ]]
		then
			export TGTFILE=/home/fred/dsms_data/${i}/${j}
		else
			export TGTFILE=/home/fred/dsms_data/${i}/sudoers.d/${j}
		fi

		printf "\rProcessing Directory %s File %s" ${i} ${j}
		
		cat data_out.txt |awk -vdirname=${i} -vfname=${j} 'BEGIN {ind=0} ind ==1 && $1 == "Directory" {exit} ind == 1 {print $0} $1 == "Directory" && $2 == dirname && $4 == fname {ind=1}' > ${TGTFILE}
	done
done


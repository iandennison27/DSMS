#!/bin/bash

function check_lines_sudoers
{
	# Check all lines and their occurence
	printf "\n"
	cat /dev/null > /tmp/linesum
	cd ${SRCDIR}
	for i in $(ls -A |grep -v vmms1)
	do
        	if [[ ! -d /home/fred/dsms_data/${i} ]]
        	then
                	continue
        	fi
        	# Get sudoers details
		cat /home/fred/dsms_data/${i}/sudoers |awk 'NF > 0 && substr($1, 1, 1) != "#" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |sed 's/ $//g' |sort -r |awk -vsrc=${i} '{printf("%s:%s\n", src, $0)}' >> /tmp/linesum
	done

	export TOTCOUNT=`cat /tmp/linesum |awk -F":" '{print $1}' |sort -u |wc -l`
	# Now loop through and count lines
	cat /dev/null > /tmp/linesumcnt
	export LNCOUNT=`cat /tmp/linesum |wc -l`
	while (( $LNCOUNT > 0 ))
	do
		# Strip out (need to handle *)
		export LINE1=`head -n 1 /tmp/linesum`
		export PAR1=`echo "${LINE1}" |awk -F":" '{print $1}'`
		export PARLEFT=`echo "${LINE1}" |sed "s/^${PAR1}://g" |sed 's/\\*/\\\\\*/g'`
	
		export PARCNT=`grep ":${PARLEFT}$" /tmp/linesum |wc -l`
		printf "%3i %s\n" ${PARCNT} "${PARLEFT}" >> /tmp/linesumcnt

		grep -v ":${PARLEFT}$" /tmp/linesum > /tmp/linesum_2
		cp /tmp/linesum_2 /tmp/linesum
		export LNCOUNT=`cat /tmp/linesum |wc -l`
	done

	echo "TOTAL COUNT = ${TOTCOUNT} SUDOERS ONLY!"
	cat /tmp/linesumcnt |sort -k1,1 -rn
	exit
}

function analyse_sudoers_defaults
{
	# NOTE: ENV RESET does not matter sequence but "env_keep=" does
	# Loop through getting all defaults on sudoers
	export DEF_EXCLUDE="env_keep secure_path"
	printf "\n"
	export SVRTOT=0
	cat /dev/null > /tmp/defaultlinedetail
	cd ${SRCDIR}
	for i in $(ls -A |grep -v vmms1)
	do
		printf "\rscanning %s" ${i}
		# Get defaults
		if [[ ! -d ${i} ]]
		then
			continue
		fi
		if [[ ! -f ${i}/sudoers ]]
		then
			continue
		fi
	
		# Strip out all defaults and format env_keep
		export  SVRTOT=`expr ${SVRTOT} \+ 1`
		cat ${SRCDIR}/${i}/sudoers |awk 'NF > 0 && substr($1, 1, 1) != "#" && $1 == "Defaults" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' > /tmp/work1_defaults
		cat /tmp/work1_defaults |sed 's/env_keep=/env_keep = /g' |sed 's/env_keep+=/env_keep += /g' > /tmp/work2_defaults

		# Find out of env_reset is present
		export RESETCNT=`grep "^Defaults env_reset" /tmp/work2_defaults |wc -l`
		if (( $RESETCNT > 0 ))
		then
			echo "${i}:reset_cnt" >> /tmp/defaultlinedetail
		fi
		cat /tmp/work2_defaults |awk '$2 == "env_keep" {print $0}' |awk 'BEGIN {cnt=0} $3 == "=" {cnt=cnt+1} {print cnt":"$0}' > /tmp/work2_defaults_sections
		
		export LASTSECTION=`tail -n 1 /tmp/work2_defaults_sections |awk -F":" '{print $1}'`
		grep "^${LASTSECTION}:" /tmp/work2_defaults_sections |sed 's/\"/ /g' |awk -vj=${i} '{for(i=4;i<=NF;i++) {printf("%s:%s\n", j, $i)}}' >> /tmp/defaultlinedetail

	done
	printf "\n"

	# Now loop and confirm how many are present
	cat /dev/null > /tmp/defaultlinedetailsum
	for i in $(cat /tmp/defaultlinedetail |awk -F":" '{print $2}' |sort -u)
	do
		export TGTLIST=""
		export FNDCNT=`grep ":${i}$" /tmp/defaultlinedetail |wc -l`
		if (( $FNDCNT < ${SVRTOT} ))
		then
			# Build list of missing servers
			for j in $(cat /tmp/defaultlinedetail |awk -F":" '{print $1}' |sort -u)
			do
				# Find out if missing and if so, add
				export MISSCNT=`grep "^${j}:${i}$" /tmp/defaultlinedetail |wc -l`
				if (( $MISSCNT < 1 ))
				then
					export TGTLIST="${TGTLIST} ${j}"
				fi
			done
		fi
		echo "${FNDCNT} ${i} ${TGTLIST}" >> /tmp/defaultlinedetailsum	
	done
	printf "DEFAULTS ENVIRONMENTS - Total servers is %i\n" ${SVRTOT}
	cat /tmp/defaultlinedetailsum |sort -k1,1 -rn	
	printf "\n"

	# Now detect non-environments and summarise
        cat /dev/null > /tmp/defaultlineremainder
        cat /dev/null > /tmp/defaultlineerror
        cd ${SRCDIR}
        for i in $(ls -A |grep -v vmms1)
        do
                printf "\rre-scanning %s" ${i}
                # Get defaults
                if [[ ! -d ${i} ]]
                then
                        continue
                fi
                if [[ ! -f ${i}/sudoers ]]
                then
                        continue
                fi

                # Strip out all defaults and format env_keep
                cat ${SRCDIR}/${i}/sudoers |awk 'NF > 0 && substr($1, 1, 1) != "#" && substr($1, 1, 8) == "Defaults" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' > /tmp/work1_defaults
		grep -i "=" /tmp/work1_defaults |awk '$3 != "=" && $3 != "=+" {print $0}' |awk -vsvr=${i} '{print "ERROR: No defaults space delimeter svr"$0}' >> /tmp/defaultlineerror
	
		# Strip out non-env variables 
		cat /tmp/work1_defaults |awk '$2 != "env_keep" && $2 != "env_reset" {print $0}' > /tmp/work2_defaults
	
		# Look for unsetting and resetting - maybe later
			
                # Loop around counting occurences
		cat /tmp/work2_defaults |awk -vsvr=${i} '{printf("%s:%s\n", svr, $0)}' >> /tmp/defaultlineremainder
	done
        printf "\n"

	# Loop through and show counts
	cat /dev/null > /tmp/defaultlineremainder_sort
	cat /tmp/defaultlineremainder |awk -F":" '{for(i=2;i<=NF;i++) {printf("%s:", $i)}}{printf "\n"}' |sed 's/:$//g' |sort -u -r> /tmp/defaultlineremainder_format 
	export LNCOUNT=`cat /tmp/defaultlineremainder_format |wc -l`
	while (( $LNCOUNT > 0 ))
	do
		export LINE1=`head -n 1 /tmp/defaultlineremainder_format`
		export FNDCNT=`grep ":${LINE1}$" /tmp/defaultlineremainder |wc -l`
		echo "${FNDCNT} ${LINE1}" >> /tmp/defaultlineremainder_sort

		export LNCOUNT=`cat /tmp/defaultlineremainder_format |wc -l`
		grep -v "${LINE1}" /tmp/defaultlineremainder_format > /tmp/defaultlineremainder_format_2
		cp /tmp/defaultlineremainder_format_2 /tmp/defaultlineremainder_format
	done

	cat /tmp/defaultlineremainder_sort |sort -k1,1 -rn	
	# Look for unset then reset
}

function checksums
{
	# Loop through files and get filesum then display
	cat /dev/null > /tmp/output
	cd ${SRCDIR}
	for i in $(ls -A |grep -v vmms1)
	do
		if [[ ! -d /home/fred/dsms_data/${i} ]]
		then
			continue
		fi
		# Get sudoers details
		export SUM=`sum /home/fred/dsms_data/${i}/sudoers |awk '{print $1"_"$2}'`
		export LNCNT=`cat /home/fred/dsms_data/${i}/sudoers |wc -l`
		echo "${i} sudoers ${SUM} ${LNCNT}" >> /tmp/output
		for j in $(ls -A /home/fred/dsms_data/${i}/sudoers.d)
		do
			export SUM=`sum /home/fred/dsms_data/${i}/sudoers.d/${j} |awk '{print $1"_"$2}'`
			export LNCNT=`cat /home/fred/dsms_data/${i}/sudoers.d/${j} |wc -l`
			echo "${i} ${j} ${SUM} ${LNCNT}" >> /tmp/output
		done
	done
	ls -al /tmp/output
	
	# Now summarise by filename
	printf " Filename            | Sum     | Found | # Lines | Hosts\n"
	printf " ====================+=========+=======+=========+=========+\n"
	for i in $(cat /tmp/output |awk '{print $2}' |sort -u)
	do
		# Get list of checksums
		for j in $(grep " ${i} " /tmp/output |awk '{print $3}' |sort -u)
		do
			export FNDCNT=`grep " ${i} ${j} " /tmp/output |wc -l`
			export LNCNT=`grep " ${i} ${j} " /tmp/output |head -n 1 |awk '{print $4}'`
			printf " %-20s %-10s    %3i       %3i |" ${i} ${j} ${FNDCNT} ${LNCNT}
			for k in $(grep " ${i} ${j} " /tmp/output |awk '{print $1}')
			do
				printf " %s " ${k}
			done
			printf "\n"
	
		done
	done
}

function rules_format
{
	# Analyse rules - determine usage of hosts, ALL, negation, colons
	echo "rules analysis - all hosts"
	
}
# Script to summarise files
export SRCDIR=/home/fred/dsms_data

export PARM=$*
export ALLCOUNT=`echo "${PARM}" |grep -i all |wc -l`
export LNCOUNT=`echo "${PARM}" |grep -i help |wc -l`
if (( $LNCOUNT > 0 ))
then
	echo "summarise.sh  - lines = check line counts"
	echo "              - defaults = check defaults entries"
	echo "              - checksums = print checksums"
	echo "              - rules = analyse rules"
	echo "              - all = all checks"
	exit
fi
# Loop through files and get filesum then display
export LNCOUNT=`echo "${PARM}" |grep -i lines |wc -l`
if (( $LNCOUNT > 0 || $ALLCOUNT > 0 ))
then
	check_lines_sudoers
fi
# Loop through files and get filesum then display
export LNCOUNT=`echo "${PARM}" |grep -i defaults |wc -l`
if (( $LNCOUNT > 0 || $ALLCOUNT > 0 ))
then
	analyse_sudoers_defaults
fi
# Loop through checksums
export LNCOUNT=`echo "${PARM}" |grep -i checksums |wc -l`
if (( $LNCOUNT > 0 || $ALLCOUNT > 0 ))
then
	checksums
fi
# Loop through checksums
export LNCOUNT=`echo "${PARM}" |grep -i rules |wc -l`
if (( $LNCOUNT > 0 || $ALLCOUNT > 0 ))
then
	rules_format
fi


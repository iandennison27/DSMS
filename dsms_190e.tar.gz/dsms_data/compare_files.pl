#!/usr/bin/perl

# Set defaults etc
use strict;
use warnings;

# Process argv, loop through arguments
my $numberargs=$#ARGV+1;
print "Number of arguments $numberargs\n";
if ($numberargs < 1 || $numberargs > 2 ) {
                        print "Usage: ./compare_files.pl [original] [duplicate]\n";
			exit(0);
                }

my $myfiletest; # Test file opne
my $origfile; # Original file handle
my $duplfile; # Original file handle

for (my $i = 0; $i < @ARGV; $i++) {
        my $argin = $ARGV[$i];
	print "argin = $argin i = ${i}\n";
	if ( $argin eq "-h" || $argin eq "-help" ) {
                        print "Usage: ./compare_files.pl [original] [duplicate]\n";
			exit(0);
	}

	# scan for filename
	open($myfiletest, "<", $argin) or die "Cannot open file $argin\n";
	close($myfiletest);
	if ( $i == 0 ) {
		$origfile=$argin;
	}	
	if ( $i == 1 ) {
		$duplfile=$argin;
	}	
}

print "Original File $origfile\n";
print "Duplicate File $duplfile\n";

# call subroutine, file1

# call subroutine, file2

# report on differences
# 1. Defaults and environment variables

# 2. specific rule combinations missing

# 3. Summarise missing hosts

# 4. summarise missing yusers

# 5. summarise missing commands

# (all can be missing and unused , present and unused, missing and used)

# Create subroutine, deconstruct sudoers file to temp file


#!/bin/bash

# Script to compare files
function breakdownsudoers
{
	export DESTFILE=/tmp/work1_output
	cat /dev/null > /tmp/work1_output
	
	# Format, remove comments (except for includedir), wrap lines, enhance asterisks
	cat ${SRCFILE} |awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0} $1 == "#includedir" {print $0}' |awk '{for(i=1;i<=NF;i++) {printf("%s ", $i)}}{printf "\n"}' |awk 'substr($NF, 0, 1) == "\\" {printf("%s ", $0)} substr($NF, 0, 1) != "\\" {print $0}' |sed 's/\\//g' | sed 's/\*/\\\*/g' > /tmp/work1_file_format

	# Pull out defaults - env_reset, env_keep, securepath, others
	
	# Pull out Hosts, Users and Command Aliass and flatten to temp area
	grep "^Host_Alias" /tmp/work1_file_format  |sed 's/=/ = /g' |sed 's/,/ /g' |awk '{name=$2}{for(i=4;i<=NF;i++) {printf("Host:%s:%s\n", name, $i)}}' > /tmp/flat_group
	# Need to flatten this twice, as commas indicate space not a delimeter
	grep "^Command_Alias" /tmp/work1_file_format  |sed 's/=/ = /g' |awk '{name=$2;printf("%s,", $2)}{for(i=4;i<=NF;i++) {printf("%s ", $i)}}' |awk -F"," '{name=$1} {for(i=2;i<=NF;i++) {printf("Command:%s:%s\n", name, $i)}}' |sed 's/: /:/g' >> /tmp/flat_group
	grep "^User_Alias" /tmp/work1_file_format  |sed 's/=/ = /g' |sed 's/,/ /g' |awk '{name=$2}{for(i=4;i<=NF;i++) {printf("User:%s:%s\n", name, $i)}}' >> /tmp/flat_group

	# loop through until all aliases exhausted
	cp /tmp/flat_group /tmp/flat_group_work
	
	# Pull out Hosts, Users and Command Aliases and flatten

	# Pull out rules and expand out
	cat /tmp/work1_file_format |grep -v "^Defaults" |grep -v "^User_Alias" |grep -v "^Host_Alias" |grep -v "^Command_Alias" > /tmp/work1_rules_format
}

# export SRCFILE=/home/fred/dsms_data/zdredvmbw1/sudoers
export SRCFILE=/tmp/cidev_sudoers
breakdownsudoers
cp /tmp/work1_output /tmp/srcfile
ls -al /tmp/work1_file_format /tmp/flat_group /tmp/work1_rules_format

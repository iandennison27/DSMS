#!/bin/bash

# Script to strip down sudoers files

export PARM=$*
export P1=`echo "${PARM}" |awk '{print $1}'`
if [[ ! -f "${P1}" ]]
then
	echo "${P1} not a file"
	exit
fi

# Strip out and continue
cat "${P1}" |awk 'NF > 0 {print $0}' |awk 'substr($1, 1, 1) != "#" {print $0} $1 == "#includedir" {print $0}'

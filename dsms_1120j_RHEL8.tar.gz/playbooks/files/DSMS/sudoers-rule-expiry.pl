#!/usr/bin/perl

# Name: sudoers-rule-expiry.pl
# Author: Ian Dennison
# Function: Send out alert emails for rule expiry
#
# Version:
# 1.0 | 5 Nov 2024 | Initial Release
# 1.1 | 12 Nov 2024 | Send emails rather than test.html, link in sudoers-rule-expiry-extend.cgi
#
use strict;
use MIME::Lite;
use Date::Parse qw(str2time);
use POSIX qw(strftime);

use lib qw(/var/www/html);

require 'common.pl';
my $DB_Management = DB_Management();
my $DB_Sudoers = DB_Sudoers();
my $Sudoers_Location = "";
my $Default_Environment = Default_Environment();
my $System_Name = System_Name();
my $Debug_Build = Debug_Build();
my $Version = Version();
my $md5sum = md5sum();
my $cut = cut();
my $visudo = visudo();
my $cp = cp();
my $ls = ls();
my $grep = sudo_grep();
my $head = head();
my $Owner = Owner_ID();
my $Group = Group_ID();
my $Date = strftime "%Y-%m-%d", localtime;

my $Server_Hostname = Server_Hostname();
chomp($Server_Hostname);
my $Expiry_Period= Expiry_Period();
my $Expiry_Warning= Expiry_Warning();
my $Expiry_Cleanup= Expiry_Cleanup();
my $Message_Output_Limit=99;
my $CR="\n";
my $now = time;
my $then = $now + (20 * 86_400); # 86,400 seconds in a day
my $then_str = strftime('%Y-%m-%d', localtime($then));
# print "In 20 days time it will be $then_str\n";

my $Owner_Email_Address="";
my $Owner_Name="";

# Connect to Database, get list of rules with owners that expire within 14 days (change to common.pl value later)
# my $Select_Owners = $DB_Sudoers->prepare("SELECT DISTINCT `rule_owner` FROM `rules` where `expires` < NOW()-14");
# EXAMPLE: SELECT * FROM `rules` WHERE `rule_owner` <> '0' AND `expires` <> '0000-00-00' AND `expires` < NOW() + INTERVAL 14 DAY AND `expires` >= NOW();
my $Select_Owners = $DB_Sudoers->prepare("SELECT DISTINCT `rule_owner` FROM `rules`
	WHERE `rule_owner` <> '0'
	AND `expires` <> '0000-00-00'
	AND `expires` < NOW() + INTERVAL $Expiry_Warning DAY
	and `expires` >= NOW()");
$Select_Owners->execute();
while (my @Select_Owners = $Select_Owners->fetchrow_array() )
{
	# Get owner details
	my $Tracking_Master_ID;
        my $Rule_Owner = $Select_Owners[0];
	my $Rule_Owner_Details = $DB_Sudoers->prepare("SELECT `longname`, `user_email` FROM `users`
        WHERE `id` = ?");
	$Rule_Owner_Details->execute($Rule_Owner);
	my @Return_Owner_Details = $Rule_Owner_Details->fetchrow_array();
        my $Owner_Name = $Return_Owner_Details[0];
        my $Owner_Email_Address = $Return_Owner_Details[1];
	print "Found rule owner $Rule_Owner Name:$Owner_Name Email: $Owner_Email_Address\n";

	if ( $Owner_Email_Address eq "" )
	{
		$Owner_Email_Address='idza59@police.govt.nz'; # Add backup dist list to common.pl
	}

	# Track number of rules found (don't add entry to renewal_tracking table until at least 1 valid rule found)
	# Need to also confirmed ruleid not already found and managed before adding a master entry for the user and date combo.
	my $Rules_Found_Count=0;	
	my $Rules_Tracking_ID=0;
	my $html_intro='<div>Welcome to the Rules renewal Reminder, ' . $Owner_Name . '. You are responsible for the following rules which are expiring in the next ' . $Expiry_Period . ' days. <br />' . $CR . '
	Please review the links below and Approve or Deny the renewals</div><br /><br />' . $CR;
	my $html_footer='<br .><div>NZ Police policy is for Sudoers Access Rules for non-LIAM Team members to be revalidated every 90 days. Your name has been registered against certain rules as an Authoriser / Owner. Please use the links above to perform the action required.' . $CR . '<br />If you have any queries or questions, please contact the LIAM Team (LIAMTeam@police.govt.nz) and refer to "DSMS Sudoers Rule 90 Day Expiry".' . $CR . '<br />These links will stay active for 44 days, after which time they will be removed from the system<br /></div>';
	my $html_header='';
	my $html_code = $CR . '<table border="1" cellspacing="0" cellpadding="1">
		<tr><td style="width:10px"></td><td style="width:10px"></td><td style="width:10px"></td><td width=2px>Rule No</td><td width=2px>Rule Name</td><td>Host Groups</td><td>Hosts</td><td>User Groups</td><td>Users</td><td>Commands Groups</td><td>Commands</td><td>Run As</td><td>Expires</td></tr>' . $CR;

	# Now list out rules and build html file for sending out
	my $Select_Owners_Rules = $DB_Sudoers->prepare("SELECT `id`, `name`, `all_hosts`, `all_commands`, `run_as`, `expires` FROM `rules`
	WHERE `rule_owner` = ?
        AND `expires` <> '0000-00-00'
        AND `expires` < NOW() + INTERVAL $Expiry_Period DAY
        and `expires` >= NOW()");
	$Select_Owners_Rules->execute($Rule_Owner);
	while (my @Select_Owners_Rules = $Select_Owners_Rules->fetchrow_array() )
	{
        	my $Rule_Owner_ID = $Select_Owners_Rules[0];
        	my $Rule_Owner_Name = $Select_Owners_Rules[1];
        	my $Rule_Owner_All_Hosts = $Select_Owners_Rules[2];
        	my $Rule_Owner_All_Commands = $Select_Owners_Rules[3];
        	my $Rule_Owner_Run_As = $Select_Owners_Rules[4];
        	my $Rule_Owner_Expires = $Select_Owners_Rules[5];
		print " - For owner $Rule_Owner, found Rule id $Rule_Owner_ID Name: $Rule_Owner_Name, expires: $Rule_Owner_Expires\n";
		print "      Run_as:  $Rule_Owner_Run_As\n";

		# Check not already tracked in renewal_tracking_rules
		my $Rule_Exist_Check = $DB_Sudoers->prepare("SELECT `id` FROM `renewal_tracking_rules`
        		WHERE `rule_id` = ? ");
		$Rule_Exist_Check->execute($Rule_Owner_ID);
		my @Rule_Exist_Return= $Rule_Exist_Check->fetchrow_array();
		my $Rule_Exist_Value=$Rule_Exist_Return[0];
		if ($Rule_Exist_Value)
		{
			# Found a row, so skip this rule
			print "Skipping this rule $Rule_Owner_ID, already exists in renewal_tracking_rules\n";
			next;
		}	

		# Add entry to renewal_tracking and renewal_tracking_rules tables
		$Rules_Found_Count+=1;
		if ( $Rules_Found_Count == 1 )
		{
			# Look for old entry for d and date, if present load up otherwise add
			my $Tracking_Query = $DB_Sudoers->prepare("SELECT `id` from `renewal_tracking`
				WHERE `admin_id` = ?
				AND `generation_date` = ? ");
        		$Tracking_Query->execute($Rule_Owner, $Date);
	
			my @Tracking_Query_Result = $Tracking_Query->fetchrow_array();
			my $Tracking_Query_Return_ID = $Tracking_Query_Result[0];
			
			if ( $Tracking_Query_Return_ID )
			{
				# Load up Tracking_Master_ID
				print "Found existing ID $Tracking_Query_Return_ID\n";
				$Tracking_Master_ID=$Tracking_Query_Return_ID;
			} else
			{
				# First rule found for this user, add an entry to renewal_tracking table and grab id
        			my $Tracking_Insert = $DB_Sudoers->prepare("INSERT INTO `renewal_tracking` (
                			`id`,
                			`admin_id`,
                			`generation_date`,
                			`renew_expires`,
                			`status`
        				)
        			VALUES (
                			NULL,
                			?,
                			?,
                			?,
                			?
        			)");
			
        			$Tracking_Insert->execute($Rule_Owner, $Date, $then_str, '0');

        			$Tracking_Master_ID = $DB_Sudoers->{mysql_insertid};
				print "Added new Tracking ID $Tracking_Master_ID\n";
			}

			# Load up html header now we know tracking reference
			$html_header='<div><table border="0" cellspacing="0" cellpadding="1">
        		<tr><td><a href=https://' . $Server_Hostname . '/sudoers-rule-expiry-extend.cgi?action="Approve";tracking_ref=' . $Tracking_Master_ID .'>Approve All Rules</a></td></tr>' . $CR . '<tr><td><a href=https://' . $Server_Hostname . '/sudoers-rule-expiry-extend.cgi?action="Deny";tracking_ref=' . $Tracking_Master_ID .'>Deny All Rules</a></td><td> For all rules listed below</td></tr></table><br /><br />' . $CR;
		}
		# Add entry into renewal_tracking_rules
        	my $Tracking_Rule_Insert = $DB_Sudoers->prepare("INSERT INTO `renewal_tracking_rules` (
                			`id`,
                			`renewal_id`,
                			`rule_id`, `expires`, `status`) VALUES ( NULL, ?, ?, ?,
                			?
        			)");
        	$Tracking_Rule_Insert->execute($Tracking_Master_ID, $Rule_Owner_ID, $Rule_Owner_Expires, '0');

    		my $Tracking_Rule_Master_ID = $DB_Sudoers->{mysql_insertid};
		print "Added new Rule Tracking ID $Tracking_Rule_Master_ID Master of $Tracking_Master_ID\n";
	
					
		# Loop through and build dump of rules into HTML variable for email dispatch
		my $Hosts_Groups_List_Output="";
		my $Hosts_Groups_List_Output_Count=0;
		if ( $Rule_Owner_All_Hosts)
		{
			$Hosts_Groups_List_Output="ALL Hosts,<br>";
			$Hosts_Groups_List_Output_Count+=1;
		}		

		# select host_groups.system_group_prefix, host_groups.groupname from lnk_rules_to_host_groups inner join host_groups on lnk_rules_to_host_groups.host_group=host_groups.id and rule='4';
		my $Host_Group_Query  =  $DB_Sudoers->prepare("SELECT host_groups.system_group_prefix, host_groups.groupname FROM lnk_rules_to_host_groups
			 inner join host_groups on lnk_rules_to_host_groups.host_group=host_groups.id
                          WHERE `rule` = ? ");
	        $Host_Group_Query->execute($Rule_Owner_ID);
        	while (my @Select_Group_Query = $Host_Group_Query->fetchrow_array() )
        	{
			# Grab data
			my $Host_Group_Suffix=$Select_Group_Query[0];
			my $Host_Group_Name=$Select_Group_Query[1];
			$Hosts_Groups_List_Output_Count+=1;
	
			if ($Host_Group_Suffix eq "")
			{
				if ( $Hosts_Groups_List_Output_Count <= $Message_Output_Limit)
				{
					$Hosts_Groups_List_Output = $Hosts_Groups_List_Output . " " . $Host_Group_Name . ",<br>" ;
				}
			} else
			{
				if ( $Hosts_Groups_List_Output_Count <= $Message_Output_Limit)
				{
					$Hosts_Groups_List_Output = $Hosts_Groups_List_Output . " " . $Host_Group_Suffix . $Host_Group_Name . ",<br>";
				}
			}

		}

		# Check if word wrap
		if ( $Hosts_Groups_List_Output_Count > $Message_Output_Limit)
		{
			$Hosts_Groups_List_Output = $Hosts_Groups_List_Output  . "...";
		} else
		{
			$Hosts_Groups_List_Output =~ s/,<br>$//g;
		}

		# Now get hosts specific entries
                my $Hosts_List_Output="";
                my $Hosts_List_Output_Count=0;

		my $Host_Query = $DB_Sudoers->prepare("SELECT hosts.hostname FROM lnk_rules_to_hosts
			 inner join hosts on lnk_rules_to_hosts.host=hosts.id
                          WHERE `rule` = ? ");
		$Host_Query->execute($Rule_Owner_ID);
        	while (my @Select_Host_Query = $Host_Query->fetchrow_array() )
        	{
			# Grab data
			my $Host_Name=$Select_Host_Query[0];
			$Hosts_List_Output_Count+=1;
			if ( $Hosts_List_Output_Count <= $Message_Output_Limit)
                        {
                        	$Hosts_List_Output = $Hosts_List_Output . " " . $Host_Name . ",<br>" ;
                        }

		}
			
		# Check if word wrap
		if ( $Hosts_List_Output_Count > $Message_Output_Limit)
		{
			$Hosts_List_Output = $Hosts_List_Output  . "...";
		} else
		{
			$Hosts_List_Output =~ s/,<br>$//g;
		}
	
		# Now get User Groups Attached
                my $User_Groups_List_Output="";
                my $User_Groups_List_Output_Count=0;

		my $User_Group_Query = $DB_Sudoers->prepare("SELECT user_groups.groupname FROM lnk_rules_to_user_groups
			 inner join user_groups on lnk_rules_to_user_groups.user_group =user_groups.id
                          WHERE `rule` = ? ");
		$User_Group_Query->execute($Rule_Owner_ID);
        	while (my @Select_User_Group_Query = $User_Group_Query->fetchrow_array() )
        	{
			# Grab data
			my $User_Group_Name=$Select_User_Group_Query[0];
			$User_Groups_List_Output_Count+=1;
			if ( $User_Groups_List_Output_Count <= $Message_Output_Limit)
                        {
                        	$User_Groups_List_Output = $User_Groups_List_Output . " " . $User_Group_Name . ",<br>" ;
                        }

		}
			
		# Check if word wrap
		if ( $User_Groups_List_Output_Count > $Message_Output_Limit)
		{
			$User_Groups_List_Output = $User_Groups_List_Output  . "...";
		} else
		{
			$User_Groups_List_Output =~ s/,<br>$//g;
		}
	
		# Now get User specific entries
                my $Users_List_Output="";
                my $Users_List_Output_Count=0;

		my $User_Query = $DB_Sudoers->prepare("SELECT users.username FROM lnk_rules_to_users
			 inner join users on lnk_rules_to_users.user=users.id
                          WHERE `rule` = ? ");
		$User_Query->execute($Rule_Owner_ID);
        	while (my @Select_User_Query = $User_Query->fetchrow_array() )
        	{
			# Grab data
			my $User_Name=$Select_User_Query[0];
			$Users_List_Output_Count+=1;
			if ( $Users_List_Output_Count <= $Message_Output_Limit)
                        {
                        	$Users_List_Output = $Users_List_Output . " " . $User_Name . ",<br>" ;
                        }

		}
			
		# Check if word wrap
		if ( $Users_List_Output_Count > $Message_Output_Limit)
		{
			$Users_List_Output = $Users_List_Output  . "...";
		} else
		{
			$Users_List_Output =~ s/,<br>$//g;
		}

		# Detect Command Groups
		my $Command_Groups_List_Output="";
		my $Command_Groups_List_Output_Count=0;
		if ( $Rule_Owner_All_Commands)
		{
			$Command_Groups_List_Output="ALL Commands,<br>";
			$Command_Groups_List_Output_Count+=1;
		}		

		# select command_groups.system_group_prefix, host_groups.groupname from lnk_rules_to_host_groups inner join host_groups on lnk_rules_to_host_groups.host_group=host_groups.id and rule='4';
		my $Command_Group_Query  =  $DB_Sudoers->prepare("SELECT command_groups.groupname FROM lnk_rules_to_command_groups
			 inner join command_groups on lnk_rules_to_command_groups.command_group=command_groups.id
                          WHERE `rule` = ? ");
	        $Command_Group_Query->execute($Rule_Owner_ID);
        	while (my @Command_Group_Query = $Command_Group_Query->fetchrow_array() )
        	{
			# Grab data
			my $Command_Group_Name=$Command_Group_Query[0];
			$Command_Groups_List_Output_Count+=1;
			if ( $Command_Groups_List_Output_Count <= $Message_Output_Limit)
                        {
                        	$Command_Groups_List_Output = $Command_Groups_List_Output . " " . $Command_Group_Name . ",<br>" ;
                        }
		}

		# Check if word wrap
		if ( $Command_Groups_List_Output_Count > $Message_Output_Limit)
		{
			$Command_Groups_List_Output = $Command_Groups_List_Output  . "...";
		} else
		{
			$Command_Groups_List_Output =~ s/,<br>$//g;
		}

		# Now get Command specific entries
                my $Command_List_Output="";
                my $Command_List_Output_Count=0;

		my $Command_Query = $DB_Sudoers->prepare("SELECT commands.command_alias FROM lnk_rules_to_commands
			 inner join commands on lnk_rules_to_commands.command=commands.id
                          WHERE `rule` = ? ");
		$Command_Query->execute($Rule_Owner_ID);
        	while (my @Select_Command_Query = $Command_Query->fetchrow_array() )
        	{
			# Grab data
			my $Command_Name=$Select_Command_Query[0];
			$Command_List_Output_Count+=1;
			if ( $Command_List_Output_Count <= $Message_Output_Limit)
                        {
                        	$Command_List_Output = $Command_List_Output . " " . $Command_Name . ",<br>" ;
                        }

		}
			
		# Check if word wrap
		if ( $Command_List_Output_Count > $Message_Output_Limit)
		{
			$Command_List_Output = $Command_List_Output  . "...";
		} else
		{
			$Command_List_Output =~ s/,<br>$//g;
		}

		$html_code = $html_code . 
		'<tr><td style="width:10px"></td><td style="width:10px"><a href=https://' . $Server_Hostname . '/sudoers-rule-expiry-extend.cgi?action="Approve";ruleid=' . $Rule_Owner_ID . '>Approve</a></td><td><a href=https://' . $Server_Hostname . '/sudoers-rule-expiry-extend.cgi?action="Deny";ruleid='. $Rule_Owner_ID . '>Deny</a></td><td>' . $Rule_Owner_ID . '</td><td>' . $Rule_Owner_Name . '</td><td>' . $Hosts_Groups_List_Output . '</td><td>' . $Hosts_List_Output . '</td><td>' . $User_Groups_List_Output . '</td><td>' . $Users_List_Output . '</td><td>' . $Command_Groups_List_Output . '</td><td>' . $Command_List_Output . '</td><td>' . $Rule_Owner_Run_As . '</td><td>' . $Rule_Owner_Expires . '</td></tr>' . $CR;
		# </table><br /><br />'#;
		print "\n";
	
	}

	$html_code = $html_code . '</table></div><br/><br/>';
	# Send email to use
	open(FH, ">", "/var/www/html/test.html") or die "Could not open /var/www/html/test.html\n";
	print FH $html_intro;
	print FH $html_header;
	print FH $html_code;
	print FH $html_footer;
	close FH;	
	
	# Send mail
	if ( $Rules_Found_Count > 0)
	{
		my $Email_Body = $html_intro . $html_header . $html_code . $html_footer;
		my $Send_Email = MIME::Lite->new(
		From    => 'root@"$Hostname"',
		To      => "$Owner_Email_Address",
		Subject => "Please review Access Rules and Approve or Deny their Extension",
		Type    => "text/html",
		Data    => "$Email_Body");
		$Send_Email->send;

		print "Sending email to $Owner_Email_Address\n";
	}
}

# Now cleanup rules entries older than archive periods (see common.pl)
my @Renewal_To_Clean;
my $Renewal_Scan=$DB_Sudoers->prepare("SELECT `id` FROM `renewal_tracking`
        WHERE `generation_date` <> '0000-00-00'
        AND `generation_date` < NOW() - INTERVAL $Expiry_Cleanup DAY");
$Renewal_Scan->execute();
while (my @Select_Renewal = $Renewal_Scan->fetchrow_array() )
{
        push(@Renewal_To_Clean, $Select_Renewal[0]);
}

my $Renewal_Count = @Renewal_To_Clean;
print "Renewal Count $Renewal_Count\nExpiry_Cleanup $Expiry_Cleanup\n";
if ( $Renewal_Count > 0 )
{
        # Loop through and delete
        foreach (@Renewal_To_Clean)
        {
                # Remove entries from the renewal_tracking and renewal_tracking_rules;
                my $Work_Renewal_ID=$_;
                print " - Working on Renewal ID: $Work_Renewal_ID\n";
                my $Renewal_Removal_ID=$DB_Sudoers->prepare("DELETE FROM `renewal_tracking`
                        WHERE `id` = ?");
                $Renewal_Removal_ID->execute($Work_Renewal_ID);
                my $Renewal_Removal_Rule_ID=$DB_Sudoers->prepare("DELETE FROM `renewal_tracking_rules`
                        WHERE `renewal_id` = ?");
                $Renewal_Removal_Rule_ID->execute($Work_Renewal_ID);
        }

}


# End script



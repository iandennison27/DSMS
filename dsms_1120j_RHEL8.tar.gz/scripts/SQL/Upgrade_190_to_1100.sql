alter table host_groups add column `system_group` int(1) NOT NULL DEFAULT '0' AFTER `groupname`;
alter table host_groups add column `system_group_prefix` varchar(1) NULL AFTER `system_group`;
alter table user_groups add column `system_group_prefix` varchar(1) NULL AFTER `system_group`;
alter table user_groups add column `system_group_prefix` varchar(1) NULL AFTER `system_group`;
alter table rules add column `rule_seq` int(2) NOT NULL DEFAULT '0' AFTER `noexec`;
alter table distribution add column `last_valid_sum` varchar(255) NULL AFTER `status`;

CREATE TABLE `profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `profile_alias` varchar(128) NOT NULL,
  `profile_filename` varchar(1000) NOT NULL,
  `expires` date NOT NULL,
  `active` int(1) NOT NULL,
  `last_modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `modified_by` varchar(128) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `profile_alias_UNIQUE` (`profile_alias`)
); 


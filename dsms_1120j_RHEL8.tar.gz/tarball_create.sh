#!/bin/bash

if [[ -f dsms_1120j_RHEL8.tar.gz ]]
then
	rm -f dsms_1120j_RHEL8.tar.gz
fi

tar -cvzf dsms_1120j_RHEL8.tar.gz -T filelist

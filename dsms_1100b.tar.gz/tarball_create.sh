#!/bin/bash

if [[ -f dsms_1100a.tar.gz ]]
then
	rm -f dsms_1100a.tar.gz
fi

tar -cvzf dsms_1100a.tar.gz -T filelist

#!/bin/bash

if [[ -f dsms_1100h.tar.gz ]]
then
	rm -f dsms_1100h.tar.gz
fi

tar -cvzf dsms_1100h.tar.gz -T filelist

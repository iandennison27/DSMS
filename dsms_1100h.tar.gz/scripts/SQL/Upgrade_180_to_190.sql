alter table host_groups add column `system_group` int(1) NOT NULL DEFAULT '0' AFTER `groupname`;
alter table host_groups add column `system_group_prefix` varchar(1) NULL AFTER `system_group`;
alter table user_groups add column `system_group_prefix` varchar(1) NULL AFTER `system_group`;


#!/bin/bash

# Script to build and deploy
# # Distrubuted Sudoers Management System Build and Distribution Processes
# */10 * * * * root cd /var/www/html/ > /dev/null 2>&1 && ./sudoers-build.pl > /dev/null 2>&1 && ./distribution.pl > /dev/null 2>&1

# Change to directory and build
cd /var/www/html/
./sudoers-build.pl 2>&1 > /tmp/work_1a_${PID}

./distribution.pl 2>&1 > /tmp/work_1b_${PID}

export DTG=`date '+%Y%m%d-%H%M%S'`
echo "$DTG START DISTRIBUTION" >> /var/log/dsms_build_distr.log
cat /tmp/work_1a_${PID} |awk -vdtg=${DTG} '{print dtg" "$0}' >> /var/log/dsms_build_distr.log
cat /tmp/work_1b_${PID} |awk -vdtg=${DTG} '{print dtg" "$0}' >> /var/log/dsms_build_distr.log
echo "$DTG END DISTRIBUTION" >> /var/log/dsms_build_distr.log

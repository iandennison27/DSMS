#!/bin/bash

if [[ -f dsms_1100c.tar.gz ]]
then
	rm -f dsms_1100c.tar.gz
fi

tar -cvzf dsms_1100c.tar.gz -T filelist

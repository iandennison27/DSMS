#!/bin/bash 

function setup_database
{
	# Note: db should already have been run
	export MYSQLPASS=`grep "MYSQLPASS:" /tmp/dsms_install_config |head -n 1 |awk -F":" '{print $2}'`
	if [[ "${MYSQLPASS}" == "" ]]
	then
            # Define root password for DB
                echo "Enter new MySQL root password:"
                read NEWPASS

                if [[ $NEWPASS = "" ]]
                then
                        exit
                fi

		# Validate - cannot use ! or $
		export ERRCNT=`echo "${NEWPASS}" |grep -i "\!" |wc -l`
		if (( $ERRCNT > 0 ))
		then
			echo "No special cfacters in pasword - exiting"
			exit
		fi
                mysqladmin -u root password "$NEWPASS"
		grep -v "^MYSQLPASS:" /tmp/dsms_install_config > /tmp/dsms_install_config_2
		echo "MYSQLPASS:${NEWPASS}" >> /tmp/dsms_install_config_2
		cp /tmp/dsms_install_config_2 /tmp/dsms_install_config
		export MYSQLPASS=${NEWPASS}
	fi

	# Now check existence of databases
        mysql -h localhost -u root -p${MYSQLPASS} -e 'show databases;' 2>&1 > /tmp/login_result.${PID}
        # ERROR 1045 (28000): Access denied for user
        export ERRCNT=`grep -iE 'ERROR|Access denied for user' /tmp/login_result.${PID} |wc -l`
        if (( $ERRCNT > 0 ))
        then
                echo "Could not validate password - exiting"
                exit
        fi

	# Check if Sudoers exists and if not, create it; if so, prompt to wipte
	export ANS=Y
	export FNDCNT=`grep Sudoers /tmp/login_result.${PID} |wc -l`
	if (( $FNDCNT > 0 ))
	then
		echo "Database Sudoers exists - do you want to recreate [YN]?"
		read ANS
		if [[ "${ANS}" == [Yy] ]]
		then
			echo "Dropping users - ignore any error messages about users not existing"
			cd ${WORKDIR}/scripts/SQL
			mysql -u root -p${MYSQLPASS} --force < Drop_Users.sql 2>&1 > /tmp/output_sql_${PID}.log
			systemctl restart mariadb
		fi
	fi

	if [[ "${ANS}" == [Yy] ]]
	then
		# Recreate or primary create
		echo "Creating databases - pay attention to errors now"
		cd ${WORKDIR}/scripts/SQL
		mysql -u root -p${MYSQLPASS} < Full_Schema.sql 2>&1 > /tmp/output_sql_${PID}.log
		export ERRCNT=`grep -i error /tmp/output_sql_${PID}.log |wc -l`
                if (( $ERRCNT > 0 ))
                then
                        echo "Encountered a problem - please review log"
                        cat /tmp/output_sql_${PID}.log
                        exit 1
                fi
                echo "Creating DB structures - OK"
	
		# Recreate users	
		cd ${WORKDIR}/scripts/SQL
		mysql -u root -p${MYSQLPASS} < Default_Users.sql 2>&1 > /tmp/output_sql2_${PID}.log
                echo "output results"
                export ERRCNT=`grep -i error /tmp/output_sql2_${PID}.log |wc -l`
                if (( $ERRCNT > 0 ))
                then
                        echo "Error found return to continue"
                        cat /tmp/output_sql2_${PID}.log
                        read
                else
                        echo "Creating user privileges - OK"
		fi
	fi
}
function setup_ssl_certs
{
	# Run script to generate
        cd ${WORKDIR}
        echo "Generating SSL Keys..."
        openssl genrsa -out DSMS.key 4096
        export RC1=$?

        # Enter ssl conf
        echo "Generating SSL Cert..."
        openssl req -new -key DSMS.key -out DSMS.csr
        export RC2=$?

        # Now sign cert and copy out
        openssl x509 -req -days 3652 -in DSMS.csr -signkey DSMS.key -out DSMS.crt
        export RC3=$?

	export RCNEW="${RC1}${RC2}${RC3}"

	if [[ "${RCNEW}" != "000" ]]
	then
		echo "Problem generating cert - exiting"
		exit
	fi

	cp DSMS.key ${WORKDIR}/playbooks/files/certs
	cp DSMS.csr ${WORKDIR}/playbooks/files/certs
	cp DSMS.crt ${WORKDIR}/playbooks/files/certs

	echo "Generated cert files ${WORKDIR}/playbooks/files/certs"
	ls -al ${WORKDIR}/playbooks/files/certs

}

# Script to setup 
if [[ ! -f /tmp/dsms_install_config ]]
then
	touch /tmp/dsms_install_config
fi

# Enter working directory
export WDIR=`grep "^WORKDIR:" /tmp/dsms_install_config |head -n 1 |awk -F":" '{print $2}'`
if [[ "${WDIR}" == "" ]]
then
	export WDIR=`pwd`
fi
printf "Enter working directory (%s):" ${WDIR}
read NEWDIR
if [[ "${NEWDIR}" == "" ]]
then
	export NEWDIR=${WDIR}
fi

# Validate directory
if [[ ! -d ${NEWDIR} ]]
then
	echo "${NEWDIR} Not a valid directory"
	exit
fi

# Update config file
grep -v "^WORKDIR:" /tmp/dsms_install_config > /tmp/dsms_install_config_2
echo "WORKDIR:${NEWDIR}" >> /tmp/dsms_install_config_2
cp /tmp/dsms_install_config_2 /tmp/dsms_install_config
grep -v "^work_dir:"  ${NEWDIR}/playbooks/host_vars/localhost.yaml > /tmp/localhost.yaml
echo "work_dir: '${NEWDIR}'" >> /tmp/localhost.yaml
cp /tmp/localhost.yaml ${NEWDIR}/playbooks/host_vars/localhost.yaml

# Now specify destination directory
export DESTDIR=`grep "^DESTDIR:" /tmp/dsms_install_config |head -n 1 |awk -F":" '{print $2}'`
printf "Enter destination directory (%s):" ${DESTDIR}
read NEWDEST
if [[ "${NEWDEST}" == "" ]]
then
	export NEWDEST=${DESTDIR}
fi

# Update config file and ansible variable file
grep -v "^DESTDIR:" /tmp/dsms_install_config > /tmp/dsms_install_config_2
echo "DESTDIR:${NEWDEST}" >> /tmp/dsms_install_config_2
cp /tmp/dsms_install_config_2 /tmp/dsms_install_config
grep -v "^dest_dir:"  ${NEWDIR}/playbooks/host_vars/localhost.yaml > /tmp/localhost.yaml
echo "dest_dir: '${NEWDEST}'" >> /tmp/localhost.yaml
cp /tmp/localhost.yaml ${NEWDIR}/playbooks/host_vars/localhost.yaml

# Check if certs generated and if not, generate
export WORKDIR=${NEWDIR}
if [[ ! -f ${WORKDIR}/playbooks/files/certs ]]
then
	mkdir -p ${WORKDIR}/playbooks/files/certs
fi
export FCNT=`cd ${WORKDIR}/playbooks/files/certs;ls -A |wc -l`
if (( $FCNT < 1 ))
then 
	echo "No certs generated - do you wish to create? [YN]"
	read ANS
	if [[ "${ANS}" == [Yy] ]]
	then
		setup_ssl_certs
	fi
fi

# check for cdrom repo
export VALCNT=`strings /etc/mtab |grep cdrom |wc -l`
if (( $VALCNT < 1 ))
then
	echo "reminder - install needs RHEL Base OS cd mounted - are you OK to continue?"
	read ANS
	if [[ "${ANS}" != [Yy] ]]
	then
		exit
	fi
fi

# Check if ansible installed
if [[ ! -f /etc/yum.repos.d/ansible_local.repo ]]
then
	echo "[ansible_local]" > /etc/yum.repos.d/ansible_local.repo
	echo "name=local ansible repo" >> /etc/yum.repos.d/ansible_local.repo
	echo "baseurl=file://${WORKDIR}/rpms" >> /etc/yum.repos.d/ansible_local.repo
	echo "gpgcheck=0" >> /etc/yum.repos.d/ansible_local.repo
	echo "enabled=1" >> /etc/yum.repos.d/ansible_local.repo
fi
if [[ ! -f /tmp/rpm.qa ]]
then
	echo "Generating rpm database"
	rpm -qa > /tmp/rpm.qa
fi

export ANSCNT=`grep "^ansible-[0-9]" /tmp/rpm.qa |wc -l`
if (( $ANSCNT < 1 ))
then
	echo "Checking rpm database"
	rpm -qa > /tmp/rpm.qa
	export ANS2CNT=`grep -i "^ansible-[0-9]" /tmp/rpm.qa |wc -l`
	if (( $ANS2CNT < 1 ))
	then
		echo "Installing ansible"
		yum -y install ansible
		export RC=$?
		if [[ ${RC} != "0" ]]
		then
			echo "Failed to install ansible - exiting"
			exit
		fi
	fi	
fi

# Check if repo installed

# Install applications
echo "install applications"
/usr/bin/ansible-playbook playbooks/setup_applications.yml

echo "next steps - setup database"
setup_database

# Now rollout dsms
cd ${WORKDIR}
/usr/bin/ansible-playbook playbooks/rollout_dsms.yml

# Configure selinux - just disable for now
export SESTATE=`/usr/sbin/getenforce |head -n 1`
if [[ "${SESTATE}" == "Enforcing" ]]
then
	echo "Consider disabling Selinux - Y/N?"
	read ANS
	if [[ "${ANS}" == [Yy] ]]
	then
		# Disable and change config file
		setenforce 0
		sed -i "s/^SELINUX=.*$/SELINUX=permissive/g" /etc/selinux/config
	fi
fi	

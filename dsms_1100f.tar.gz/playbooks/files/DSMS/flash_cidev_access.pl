#!/usr/bin/perl

use strict;
use Digest::SHA qw(sha512_hex);
use MIME::Lite;
# use Date::Parse qw(str2time);
use POSIX qw(strftime);

require 'common.pl';
my $System_Name = System_Name();
my $DB_Management = DB_Management();
my $DB_Sudoers = DB_Sudoers();
my ($CGI, $Session, $Cookie) = CGI();
my $Recovery_Email_Address = Recovery_Email_Address();
my $User_Name_Form;
my $User_Password_Form;
my $Login_Message;
my $Referer;

sub login_user {
        my $User_Admin;
        my $Login_DB_Query = $DB_Management->prepare("SELECT `password`, `salt`, `email`, `admin`, `approver`, `requires_approval`, `lockout`
        FROM `credentials`
        WHERE `username` = ?");
        $Login_DB_Query->execute($User_Name_Form);
        while ( my @DB_Query = $Login_DB_Query->fetchrow_array( ) )
        {
                my $DB_Password = $DB_Query[0];
                my $DB_Salt = $DB_Query[1];
                my $DB_Email = $DB_Query[2];
                my $DB_Admin = $DB_Query[3];
                my $DB_Approver = $DB_Query[4];
                my $DB_Requires_Approval = $DB_Query[5];
                my $DB_Lockout = $DB_Query[6];

                $User_Password_Form = $User_Password_Form . $DB_Salt;
                        $User_Password_Form = sha512_hex($User_Password_Form);

                my $Email_Password;
                if ($DB_Lockout == 1) {
                        &email_user_password_reset(12);
                        $Login_Message = "Your account is locked out.<br/>Please check your email for instructions.";
                }
                elsif ("$DB_Password" ne "$User_Password_Form")
                {

                        my $Lockout_Counter_Query = $DB_Management->prepare("SELECT `lockout_counter`
                                FROM `credentials`
                                WHERE `username` = ?");

                        $Lockout_Counter_Query->execute($User_Name_Form);

                        while ( (my $Lockout_Counter) = my @Lockout_Counter_Query = $Lockout_Counter_Query->fetchrow_array() )
                        {
                                $Lockout_Counter++;
                                my $Lockout_Increase = $DB_Management->prepare("UPDATE `credentials`
                                        SET `lockout_counter` = '$Lockout_Counter'
                                        WHERE `username` = ?");

                                $Lockout_Increase->execute($User_Name_Form);

                                        if ($Lockout_Counter >= 5) {
                                                my $Lockout_User = $DB_Management->prepare("UPDATE `credentials`
                                                        SET `lockout` = '1'
                                                        WHERE `username` = ?");
                                                $Lockout_User->execute($User_Name_Form);
                                        }

                                        $Lockout_Counter = 5 - $Lockout_Counter;
                                        $Login_Message = "You have entered an incorrect password.<br/>Attempts remaining: $Lockout_Counter";
                                        print $Login_Message;
                                        exit(0);
                        }
                }
                elsif ("$DB_Password" eq "$User_Password_Form") {

                        $Session->param('User_Name', $User_Name_Form);
                        $Session->param('User_Admin', $DB_Admin);
                        $Session->param('User_Email', $DB_Email);
                        $Session->param('User_Approver', $DB_Approver);
                        $Session->param('User_Requires_Approval', $DB_Requires_Approval);

                        my $Login_User = $DB_Management->prepare("UPDATE `credentials`
                        SET `lockout_counter` = '0',
                        `last_login` = NOW()
                        WHERE `username` = ?");

                        $Login_User->execute($User_Name_Form);

                        if ($Referer ne '') {
                                print "Location: $Referer\n\n";
                        }
                        else {
                                print "OK VALIDATED Location: index.cgi\n\n";
                        }

                }
        }
        print $Login_Message;
} #sub login_user

# prompt for user
printf "Enter userid:";
$User_Name_Form = <STDIN>;
$User_Name_Form =~ s/\R//g;

# Enter password
printf "Enter password:";
system ("stty -echo");
$User_Password_Form = <STDIN>;
$User_Password_Form =~ s/\R//g;
system ("stty echo");

login_user;

# Now prompt for user groups - declare array
my @User_Groups;
my @User_Groups_ID;
my $User_Group_In;
my @Host_List;
my @Host_List_ID;
my $Host_In;

printf "Enter user group:";
$User_Group_In = <STDIN>;
$User_Group_In =~ s/\R//g;

printf "User Group $User_Group_In\n";
while ($User_Group_In ne "")
{
        # Validate user group
        printf "Validate %s\n", $User_Group_In;
        my $Existing_User_Group_Query = $DB_Sudoers->prepare("SELECT `id` from `user_groups` WHERE `groupname` = ?");
        $Existing_User_Group_Query->execute($User_Group_In);
        my $Existing_User_Group_Count = $Existing_User_Group_Query->rows();
        my $Existing_User_Group_ID = $Existing_User_Group_Query->fetchrow_array();
        if ( $Existing_User_Group_Count < 1 )
        {
                printf " User Group $User_Group_In not valid - skipping\n";
        } else
        {
                # Add ID to lista
                if ( not grep ( /^$User_Group_In/, @User_Groups ) )
                {
                        # Add to array, get id, add that to array
                        push (@User_Groups, $User_Group_In);
                        push (@User_Groups_ID, $Existing_User_Group_ID);
                }
        }

        printf "\n";
        printf " User Groups Listed: @User_Groups\n";
        printf "       Hosts Listed: @Host_List\n\n";
        printf "Enter user group:";
        $User_Group_In = <STDIN>;
        $User_Group_In =~ s/\R//g;

}

print "\nExisting ID: @User_Groups_ID\n";

# Now input hosts
printf "\n";
printf " User Groups Listed: @User_Groups\n";
printf "       Hosts Listed: @Host_List\n\n";

printf "Enter host:";
$Host_In = <STDIN>;
$Host_In =~ s/\R//g;
printf "Host  $Host_In\n";
while ($Host_In ne "")
{
        # Validate Host group
        printf "Validate %s\n", $User_Group_In;
        my $Existing_Host_Query = $DB_Sudoers->prepare("SELECT `id` from `hosts` WHERE `hostname` = ?");
        $Existing_Host_Query->execute($Host_In);
        my $Existing_Host_Count = $Existing_Host_Query->rows();
        my $Existing_Host_ID = $Existing_Host_Query->fetchrow_array();
        if ( $Existing_Host_Count < 1 )
        {
                printf " Host $Host_In not valid - skipping\n";
        } else
        {
                # Add ID to list
                if ( not grep ( /^$Host_In/, @Host_List ) )
                {
                        # Add to array, get id, add that to array
                        push (@Host_List, $Host_In);
                        push (@Host_List_ID, $Existing_Host_ID);
                }
        }

        printf "\n";
        printf " User Groups Listed: @User_Groups\n";
        printf "       Hosts Listed: @Host_List\n\n";
        printf "Enter host:";
        $Host_In = <STDIN>;
        $Host_In =~ s/\R//g;
        printf "Host  $Host_In\n";
}

printf "Host List: @Host_List\n";
printf "Host List ID: @Host_List_ID\n";

# Calculate expiry
my $Expire_Date_Add = "";
my $Curr_Year = strftime "%Y", localtime;
my $Curr_Month = strftime "%m", localtime;
my $Curr_Day = strftime "%d", localtime;
if ( $Curr_Day < 25 )
{
        my $New_Day = $Curr_Day + 3;
        my $Form_Day = substr("0" . $New_Day, -2);
        $Expire_Date_Add = $Curr_Year . "-" . $Curr_Month . "-" . $Form_Day;
} else
{
        # Check if December abnd if so add  one to year and Jan to Month
        if ( $Curr_Month == "12" )
        {
                my $New_Year = $Curr_Year + 1;
                $Expire_Date_Add = $New_Year . "-01-03";
        } else
        {
                # Else just add one to month
                my $New_Month = $Curr_Month + 1;
                my $Form_Month = substr("0" . $New_Month, -2);
                $Expire_Date_Add = $Curr_Year . "-" . $Form_Month . "-03";
        }
}

# Create rule, define variables
# $Expires_Date_Add = '0000-00-00'
printf "Create rule\n";
my $DTG = strftime "%Y%m%d_%H%M%S", localtime;
my $Rule_Name_Add = "Quickdraw_" . $DTG . "_" . $User_Name_Form;
printf "Create rule DTG = $DTG Expire Date $Expire_Date_Add\n";
my $Existing_Rule_Name_Check = $DB_Sudoers->prepare("SELECT `id`
        FROM `rules`
        WHERE `name` = ?");
        $Existing_Rule_Name_Check->execute($Rule_Name_Add);
        my $Existing_Rules = $Existing_Rule_Name_Check->rows();

if ($Existing_Rules > 0)  {
        my $Existing_ID;
        while ( my @Select_Rule_Names = $Existing_Rule_Name_Check->fetchrow_array() )
        {
               $Existing_ID = $Select_Rule_Names[0];
        }
        my $Message_Red="Rule_Name: $Rule_Name_Add already exists as ID: $Existing_ID";
        printf "$Message_Red\n";
        exit(0);
}

printf "Rule $Rule_Name_Add not found - so adding\n";
my $Rule_Insert = $DB_Sudoers->prepare("INSERT INTO `rules` (
         `name`,
         `all_hosts`,
         `all_commands`,
         `run_as`,
         `nopasswd`,
         `noexec`,
         `rule_seq`,
         `expires`,
         `active`,
         `approved`,
         `modified_by`
  )
 VALUES (
         ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
)");

# AAAA  - needs approval
$Rule_Insert->execute($Rule_Name_Add, 0, 1, 'root', 0, 0, 7, $Expire_Date_Add, 1, 1, $User_Name_Form);

my $Rule_Insert_ID = $DB_Sudoers->{mysql_insertid};

# needs approval
my $DB_Management = DB_Management();
my $Audit_Log_Submission = $DB_Management->prepare("INSERT INTO `audit_log` (
       `category`,
       `method`,
       `action`,
       `username`
  )
  VALUES (
       ?, ?, ?, ?
)");
$Audit_Log_Submission->execute("Rules", "Add", "$User_Name_Form added Quick $Rule_Name_Add to be run as root, with the PASSWD and EXEC flags, set it Active and to $Expire_Date_Add, sequence 7. The system assigned it Rule ID $Rule_Insert_ID.", $User_Name_Form);
printf "Add Rule ID $Rule_Insert_ID\n";

#  Add in approval
my $Approve_Rule = $DB_Sudoers->prepare("UPDATE `rules` SET
                `last_approved` = NOW(),
                `approved_by` = ?
                WHERE `id` = ?");
$Approve_Rule->execute($User_Name_Form, $Rule_Insert_ID);

# Audit Log
my $Audit_Log_Submission = $DB_Management->prepare("INSERT INTO `audit_log` (
        `category`,
        `method`,
        `action`,
        `username`
     )
     VALUES (
           ?, ?, ?, ?
      )");

$Audit_Log_Submission->execute("Rules", "Approve", "$User_Name_Form Approved their own rule: $Rule_Name_Add [Rule ID $Rule_Insert_ID].", $User_Name_Form);
 # / Audit Log

# Now add in Hosts
foreach my $Host (@Host_List_ID) {

        printf "Adding Host $Host to Rule $Rule_Insert_ID\n";
        my $Host_Insert = $DB_Sudoers->prepare("INSERT INTO `lnk_rules_to_hosts` (
                `id`,
                `rule`,
                `host`
        )
        VALUES (
                NULL,
                ?,
                ?
        )");

        $Host_Insert->execute($Rule_Insert_ID, $Host);

        # Audit Log
        my $Select_Host = $DB_Sudoers->prepare("SELECT `hostname` FROM `hosts` WHERE `id` = ?");
        $Select_Host->execute($Host);
        while ( (my $Name) = $Select_Host->fetchrow_array() )
        {
                my $DB_Management = DB_Management();
                my $Audit_Log_Submission = $DB_Management->prepare("INSERT INTO `audit_log` (
                        `category`,
                        `method`,
                        `action`,
                        `username`
                )
                VALUES (
                        ?,
                        ?,
                        ?,
                        ?
                )");
                $Audit_Log_Submission->execute("Rules", "Modify", "$User_Name_Form added Host $Name [Host ID $Host] to Rule $Rule_Name_Add [Rule ID $Rule_Insert_ID]", $User_Name_Form);
        }
        # / Audit Log

}

# Insert into users groups, each user group
foreach my $User_Group (@User_Groups_ID) {
        printf "Adding User Group $User_Group to Rule $Rule_Insert_ID\n";

        my $User_Insert = $DB_Sudoers->prepare("INSERT INTO `lnk_rules_to_user_groups` (
                `id`,
                `rule`,
                `user_group`
        )
        VALUES (
                NULL,
                ?,
                ?
        )");

        $User_Insert->execute($Rule_Insert_ID, $User_Group);

        # Audit Log
        my $Select_Group = $DB_Sudoers->prepare("SELECT `groupname` FROM `user_groups` WHERE `id` = ?");
        $Select_Group->execute($User_Group);
        while ( (my $Name) = $Select_Group->fetchrow_array() )
        {
                my $DB_Management = DB_Management();
                my $Audit_Log_Submission = $DB_Management->prepare("INSERT INTO `audit_log` (
                        `category`,
                        `method`,
                        `action`,
                        `username`
                )
                VALUES (
                        ?,
                        ?,
                        ?,
                        ?
                )");
                $Audit_Log_Submission->execute("Rules", "Modify", "$User_Name_Form added User Group $Name [User Group ID $User_Group] to Rule $Rule_Name_Add [Rule ID $Rule_Insert_ID]", $User_Name_Form);
        }
        # / Audit Log

}

# Now generate sudoers
system("/var/www/html/sudoers-build.pl");

# Now loop through and send out individual hosts
# my @Host_List;
foreach my $Host_Deploy (@Host_List) {

        system("/var/www/html/distribution_single.pl", $Host_Deploy);

}

printf " Rule Add Completed\n";

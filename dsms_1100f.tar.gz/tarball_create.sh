#!/bin/bash

if [[ -f dsms_1100f.tar.gz ]]
then
	rm -f dsms_1100f.tar.gz
fi

tar -cvzf dsms_1100f.tar.gz -T filelist
